#!/usr/bin/env python
# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx
import wx.grid

from plcopen.structures import IEC_KEYWORDS, TestIdentifier
from graphics.GraphicCommons import REFRESH_HIGHLIGHT_PERIOD
from controls import CustomEditableListBox, CustomGrid, CustomTable, EditorPanel

import re

DIMENSION_MODEL = re.compile("([0-9]+)\.\.([0-9]+)$")

def AppendMenu(parent, help, id, kind, text):
    if wx.VERSION >= (2, 6, 0):
        parent.Append(help=help, id=id, kind=kind, text=text)
    else:
        parent.Append(helpString=help, id=id, kind=kind, item=text)

#-------------------------------------------------------------------------------
#                            Structure Elements Table
#-------------------------------------------------------------------------------

def GetElementsTableColnames():
    _ = lambda x : x
    return ["#", _("Name"), _("Type"), _("Initial Value")]

class ElementsTable(CustomTable):
    
    """
    A custom wx.grid.Grid Table using user supplied data
    """
    def __init__(self, parent, data, colnames):
        # The base class must be initialized *first*
        CustomTable.__init__(self, parent, data, colnames)
        self.old_value = None
        
    def GetValue(self, row, col):
        if row < self.GetNumberRows():
            if col == 0:
                return row + 1
            name = str(self.data[row].get(self.GetColLabelValue(col, False), ""))
            return name
    
    def SetValue(self, row, col, value):
        if col < len(self.colnames):
            colname = self.GetColLabelValue(col, False)
            if colname == "Name":
                self.old_value = self.data[row][colname]
            self.data[row][colname] = value
    
    def GetOldValue(self):
        return self.old_value
    
    def _updateColAttrs(self, grid):
        """
        wx.grid.Grid -> update the column attributes to add the
        appropriate renderer given the column name.

        Otherwise default to the default renderer.
        """
        
        for row in range(self.GetNumberRows()):
            row_highlights = self.Highlights.get(row, {})
            for col in range(self.GetNumberCols()):
                editor = None
                renderer = None
                colname = self.GetColLabelValue(col, False)
                if col != 0:
                    grid.SetReadOnly(row, col, False)
                    if colname == "Name":
                        editor = wx.grid.GridCellTextEditor()
                        renderer = wx.grid.GridCellStringRenderer()
                    elif colname == "Initial Value":
                        editor = wx.grid.GridCellTextEditor()
                        renderer = wx.grid.GridCellStringRenderer()
                    elif colname == "Type":
                        editor = wx.grid.GridCellTextEditor()
                else:
                    grid.SetReadOnly(row, col, True)
                
                grid.SetCellEditor(row, col, editor)
                grid.SetCellRenderer(row, col, renderer)
                
                highlight_colours = row_highlights.get(colname.lower(), [(wx.WHITE, wx.BLACK)])[-1]
                grid.SetCellBackgroundColour(row, col, highlight_colours[0])
                grid.SetCellTextColour(row, col, highlight_colours[1])
            self.ResizeRow(grid, row)
    
    def AddHighlight(self, infos, highlight_type):
        row_highlights = self.Highlights.setdefault(infos[0], {})
        if infos[1] == "initial":
            col_highlights = row_highlights.setdefault("initial value", [])
        else:
            col_highlights = row_highlights.setdefault(infos[1], [])
        col_highlights.append(highlight_type)

#-------------------------------------------------------------------------------
#                          Datatype Editor class
#-------------------------------------------------------------------------------

[ID_DATATYPEEDITOR, ID_DATATYPEEDITORPANEL, ID_DATATYPEEDITORSTATICBOX,
 ID_DATATYPEEDITORDERIVATIONTYPE, ID_DATATYPEEDITORDIRECTLYPANEL,
 ID_DATATYPEEDITORSUBRANGEPANEL, ID_DATATYPEEDITORDIRECTLYBASETYPE, 
 ID_DATATYPEEDITORSUBRANGEBASETYPE, ID_DATATYPEEDITORSUBRANGEMINIMUM, 
 ID_DATATYPEEDITORSUBRANGEMAXIMUM, ID_DATATYPEEDITORDIRECTLYINITIALVALUE, 
 ID_DATATYPEEDITORSUBRANGEINITIALVALUE, ID_DATATYPEEDITORENUMERATEDPANEL,
 ID_DATATYPEEDITORENUMERATEDVALUES, ID_DATATYPEEDITORENUMERATEDINITIALVALUE,
 ID_DATATYPEEDITORARRAYPANEL, ID_DATATYPEEDITORARRAYBASETYPE, 
 ID_DATATYPEEDITORARRAYDIMENSIONS, ID_DATATYPEEDITORARRAYINITIALVALUE, 
 ID_DATATYPEEDITORSTRUCTUREPANEL, ID_DATATYPEEDITORSTRUCTUREELEMENTSGRID,
 ID_DATATYPEEDITORSTRUCTUREADDBUTTON, ID_DATATYPEEDITORSTRUCTUREDELETEBUTTON,
 ID_DATATYPEEDITORSTRUCTUREUPBUTTON, ID_DATATYPEEDITORSTRUCTUREDOWNBUTTON,
 ID_DATATYPEEDITORSTATICTEXT1, ID_DATATYPEEDITORSTATICTEXT2, 
 ID_DATATYPEEDITORSTATICTEXT3, ID_DATATYPEEDITORSTATICTEXT4, 
 ID_DATATYPEEDITORSTATICTEXT5, ID_DATATYPEEDITORSTATICTEXT6, 
 ID_DATATYPEEDITORSTATICTEXT7, ID_DATATYPEEDITORSTATICTEXT8,
 ID_DATATYPEEDITORSTATICTEXT9, ID_DATATYPEEDITORSTATICTEXT10, 
 ID_DATATYPEEDITORSTATICTEXT11, 
] = [wx.NewId() for _init_ctrls in range(36)]

def GetDatatypeTypes():
    _ = lambda x : x
    return [_("Directly"), _("Subrange"), _("Enumerated"), _("Array"), _("Structure")]
DATATYPE_TYPES_DICT = dict([(_(datatype), datatype) for datatype in GetDatatypeTypes()])

class DataTypeEditor(EditorPanel):
    
    ID = ID_DATATYPEEDITOR
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.TopSizer, 0, border=5, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.TypeInfosSizer, 0, border=5, flag=wx.GROW|wx.BOTTOM|wx.LEFT|wx.RIGHT)

    def _init_coll_MainSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)

    def _init_coll_TopSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.LEFT|wx.RIGHT)
        parent.AddWindow(self.DerivationType, 0, border=5, flag=wx.GROW|wx.RIGHT)

    def _init_coll_TypeInfosSizer_Items(self, parent):
        parent.AddWindow(self.DirectlyPanel, 1, border=0, flag=wx.ALL)
        parent.AddWindow(self.SubrangePanel, 1, border=0, flag=wx.ALL)
        parent.AddWindow(self.EnumeratedPanel, 1, border=0, flag=wx.GROW|wx.ALL)
        parent.AddWindow(self.ArrayPanel, 1, border=0, flag=wx.ALL)
        parent.AddWindow(self.StructurePanel, 1, border=0, flag=wx.GROW|wx.ALL)

    def _init_coll_DirectlyPanelSizer_Items(self, parent):
        parent.AddWindow(self.staticText2, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.DirectlyBaseType, 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddWindow(self.staticText3, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.DirectlyInitialValue, 1, border=5, flag=wx.ALL)

    def _init_coll_SubrangePanelSizer_Items(self, parent):
        parent.AddWindow(self.staticText4, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.SubrangeBaseType, 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddWindow(self.staticText5, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.SubrangeInitialValue, 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddWindow(self.staticText6, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.SubrangeMinimum, 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddWindow(wx.Size(0, 0), 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddWindow(wx.Size(0, 0), 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddWindow(self.staticText7, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.SubrangeMaximum, 1, border=5, flag=wx.GROW|wx.ALL)
        
    def _init_coll_EnumeratedPanelSizer_Items(self, parent):
        parent.AddWindow(self.EnumeratedValues, 1, border=5, flag=wx.GROW|wx.ALL)
        parent.AddSizer(self.EnumeratedPanelRightSizer, 1, border=0, flag=0)
        
    def _init_coll_EnumeratedPanelRightSizer_Items(self, parent):
        parent.AddWindow(self.staticText8, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.EnumeratedInitialValue, 1, border=5, flag=wx.ALL)

    def _init_coll_ArrayPanelSizer_Items(self, parent):
        parent.AddSizer(self.ArrayPanelLeftSizer, 0, border=0, flag=wx.GROW)
        parent.AddSizer(self.ArrayPanelRightSizer, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.ArrayDimensions, 0, border=5, flag=wx.GROW|wx.ALL)
        
    def _init_coll_ArrayPanelSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableCol(1)
        parent.AddGrowableRow(1)

    def _init_coll_ArrayPanelLeftSizer_Items(self, parent):
        parent.AddWindow(self.staticText9, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.ArrayBaseType, 1, border=5, flag=wx.GROW|wx.ALL)
    
    def _init_coll_ArrayPanelRightSizer_Items(self, parent):
        parent.AddWindow(self.staticText10, 1, border=5, flag=wx.ALIGN_CENTER_VERTICAL|wx.ALL)
        parent.AddWindow(self.ArrayInitialValue, 1, border=5, flag=wx.ALL)    

    def _init_coll_StructurePanelSizer_Items(self, parent):
        parent.AddSizer(self.StructurePanelButtonSizer, 0, border=5, flag=wx.ALL|wx.GROW)
        parent.AddWindow(self.StructureElementsGrid, 0, border=0, flag=wx.GROW)
        
    def _init_coll_StructurePanelSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)
    
    def _init_coll_StructurePanelButtonSizer_Items(self, parent):
        parent.AddWindow(self.staticText11, 0, border=0, flag=wx.ALIGN_BOTTOM)
        parent.AddWindow(self.StructureAddButton, 0, border=0, flag=0)
        parent.AddWindow(self.StructureDeleteButton, 0, border=0, flag=0)
        parent.AddWindow(self.StructureUpButton, 0, border=0, flag=0)
        parent.AddWindow(self.StructureDownButton, 0, border=0, flag=0)
    
    def _init_coll_StructurePanelButtonSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)

    def _init_sizers(self):
        self.MainSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.TopSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.TypeInfosSizer = wx.StaticBoxSizer(self.staticbox, wx.HORIZONTAL)
        self.DirectlyPanelSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.SubrangePanelSizer = wx.GridSizer(cols=4, hgap=5, rows=3, vgap=0)
        self.EnumeratedPanelSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.EnumeratedPanelRightSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.ArrayPanelSizer = wx.FlexGridSizer(cols=2, hgap=5, rows=2, vgap=0)
        self.ArrayPanelLeftSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.ArrayPanelRightSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.StructurePanelSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=0)
        self.StructurePanelButtonSizer = wx.FlexGridSizer(cols=5, hgap=5, rows=1, vgap=0)
        
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_MainSizer_Growables(self.MainSizer)
        self._init_coll_TopSizer_Items(self.TopSizer)
        self._init_coll_TypeInfosSizer_Items(self.TypeInfosSizer)
        self._init_coll_DirectlyPanelSizer_Items(self.DirectlyPanelSizer)
        self._init_coll_SubrangePanelSizer_Items(self.SubrangePanelSizer)
        self._init_coll_EnumeratedPanelSizer_Items(self.EnumeratedPanelSizer)
        self._init_coll_EnumeratedPanelRightSizer_Items(self.EnumeratedPanelRightSizer)
        self._init_coll_ArrayPanelSizer_Items(self.ArrayPanelSizer)
        self._init_coll_ArrayPanelSizer_Growables(self.ArrayPanelSizer)
        self._init_coll_ArrayPanelLeftSizer_Items(self.ArrayPanelLeftSizer)
        self._init_coll_ArrayPanelRightSizer_Items(self.ArrayPanelRightSizer)
        self._init_coll_StructurePanelSizer_Items(self.StructurePanelSizer)
        self._init_coll_StructurePanelSizer_Growables(self.StructurePanelSizer)
        self._init_coll_StructurePanelButtonSizer_Items(self.StructurePanelButtonSizer)
        self._init_coll_StructurePanelButtonSizer_Growables(self.StructurePanelButtonSizer)
        
        self.Editor.SetSizer(self.MainSizer)
        self.DirectlyPanel.SetSizer(self.DirectlyPanelSizer)
        self.SubrangePanel.SetSizer(self.SubrangePanelSizer)
        self.EnumeratedPanel.SetSizer(self.EnumeratedPanelSizer)
        self.ArrayPanel.SetSizer(self.ArrayPanelSizer)
        self.StructurePanel.SetSizer(self.StructurePanelSizer)
    
    def _init_Editor(self, prnt):
        self.Editor = wx.Panel(id=ID_DATATYPEEDITORPANEL, name='', parent=prnt,
              size=wx.Size(0, 0), style=wx.SUNKEN_BORDER)

        self.staticbox = wx.StaticBox(id=ID_DATATYPEEDITORSTATICBOX,
              label=_('Type infos:'), name='staticBox1', parent=self.Editor,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.staticText1 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT1,
              label=_('Derivation Type:'), name='staticText1', parent=self.Editor,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.DerivationType = wx.ComboBox(id=ID_DATATYPEEDITORDERIVATIONTYPE,
              name='DerivationType', parent=self.Editor, pos=wx.Point(0, 0),
              size=wx.Size(200, 28), style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnDerivationTypeChanged, id=ID_DATATYPEEDITORDERIVATIONTYPE)

        # Panel for Directly derived data types

        self.DirectlyPanel = wx.Panel(id=ID_DATATYPEEDITORDIRECTLYPANEL,
              name='DirectlyPanel', parent=self.Editor, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.staticText2 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT2,
              label=_('Base Type:'), name='staticText2', parent=self.DirectlyPanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.DirectlyBaseType = wx.ComboBox(id=ID_DATATYPEEDITORDIRECTLYBASETYPE, 
              name='DirectlyBaseType', parent=self.DirectlyPanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnInfosChanged, id=ID_DATATYPEEDITORDIRECTLYBASETYPE)

        self.staticText3 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT3,
              label=_('Initial Value:'), name='staticText3', parent=self.DirectlyPanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.DirectlyInitialValue = wx.TextCtrl(id=ID_DATATYPEEDITORDIRECTLYINITIALVALUE, 
              name='DirectlyInitialValue', parent=self.DirectlyPanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TAB_TRAVERSAL|wx.TE_PROCESS_ENTER|wx.TE_MULTILINE|wx.TE_RICH)
        self.Bind(wx.EVT_TEXT_ENTER, self.OnReturnKeyPressed, id=ID_DATATYPEEDITORDIRECTLYINITIALVALUE)

        # Panel for Subrange data types

        self.SubrangePanel = wx.Panel(id=ID_DATATYPEEDITORSUBRANGEPANEL,
              name='SubrangePanel', parent=self.Editor, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.staticText4 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT4,
              label=_('Base Type:'), name='staticText4', parent=self.SubrangePanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.SubrangeBaseType = wx.ComboBox(id=ID_DATATYPEEDITORSUBRANGEBASETYPE, 
              name='SubrangeBaseType', parent=self.SubrangePanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        self.SubrangeBaseType.SetBackgroundColour(wx.BLUE)
        self.Bind(wx.EVT_COMBOBOX, self.OnSubrangeBaseTypeChanged, id=ID_DATATYPEEDITORSUBRANGEBASETYPE)

        self.staticText5 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT5,
              label=_('Initial Value:'), name='staticText5', parent=self.SubrangePanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.SubrangeInitialValue = wx.SpinCtrl(id=ID_DATATYPEEDITORSUBRANGEINITIALVALUE, 
              name='SubrangeInitialValue', parent=self.SubrangePanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TAB_TRAVERSAL)
        self.Bind(wx.EVT_SPINCTRL, self.OnInfosChanged, id=ID_DATATYPEEDITORSUBRANGEINITIALVALUE)

        self.staticText6 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT6,
              label=_('Minimum:'), name='staticText6', parent=self.SubrangePanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.SubrangeMinimum = wx.SpinCtrl(id=ID_DATATYPEEDITORSUBRANGEMINIMUM, 
              name='SubrangeMinimum', parent=self.SubrangePanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TAB_TRAVERSAL)
        self.Bind(wx.EVT_SPINCTRL, self.OnSubrangeMinimumChanged, id=ID_DATATYPEEDITORSUBRANGEMINIMUM)

        self.staticText7 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT7,
              label=_('Maximum:'), name='staticText7', parent=self.SubrangePanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.SubrangeMaximum = wx.SpinCtrl(id=ID_DATATYPEEDITORSUBRANGEMAXIMUM, 
              name='SubrangeMaximum', parent=self.SubrangePanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TAB_TRAVERSAL)
        self.Bind(wx.EVT_SPINCTRL, self.OnSubrangeMaximumChanged, id=ID_DATATYPEEDITORSUBRANGEMAXIMUM)

        # Panel for Enumerated data types

        self.EnumeratedPanel = wx.Panel(id=ID_DATATYPEEDITORENUMERATEDPANEL,
              name='EnumeratedPanel', parent=self.Editor, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.EnumeratedValues = CustomEditableListBox(id=ID_DATATYPEEDITORENUMERATEDVALUES, 
              name='EnumeratedValues', parent=self.EnumeratedPanel, label=_("Values:"), pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.gizmos.EL_ALLOW_NEW | wx.gizmos.EL_ALLOW_EDIT | wx.gizmos.EL_ALLOW_DELETE)
        setattr(self.EnumeratedValues, "_OnLabelEndEdit", self.OnEnumeratedValueEndEdit)
        for func in ["_OnAddButton", "_OnDelButton", "_OnUpButton", "_OnDownButton"]:
            setattr(self.EnumeratedValues, func, self.OnEnumeratedValuesChanged)
        
        self.staticText8 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT8,
              label=_('Initial Value:'), name='staticText8', parent=self.EnumeratedPanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.EnumeratedInitialValue = wx.ComboBox(id=ID_DATATYPEEDITORENUMERATEDINITIALVALUE, 
              name='EnumeratedInitialValue', parent=self.EnumeratedPanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnInfosChanged, id=ID_DATATYPEEDITORENUMERATEDINITIALVALUE)
        
        # Panel for Array data types

        self.ArrayPanel = wx.Panel(id=ID_DATATYPEEDITORARRAYPANEL,
              name='ArrayPanel', parent=self.Editor, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.staticText9 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT9,
              label=_('Base Type:'), name='staticText9', parent=self.ArrayPanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.ArrayBaseType = wx.ComboBox(id=ID_DATATYPEEDITORARRAYBASETYPE, 
              name='ArrayBaseType', parent=self.ArrayPanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnInfosChanged, id=ID_DATATYPEEDITORARRAYBASETYPE)

        self.ArrayDimensions = CustomEditableListBox(id=ID_DATATYPEEDITORARRAYDIMENSIONS, 
              name='ArrayDimensions', parent=self.ArrayPanel, label=_("Dimensions:"), pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.gizmos.EL_ALLOW_NEW | wx.gizmos.EL_ALLOW_EDIT | wx.gizmos.EL_ALLOW_DELETE)
        for func in ["_OnLabelEndEdit", "_OnAddButton", "_OnDelButton", "_OnUpButton", "_OnDownButton"]:
            setattr(self.EnumeratedValues, func, self.OnDimensionsChanged)
        
        self.staticText10 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT10,
              label=_('Initial Value:'), name='staticText10', parent=self.ArrayPanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.ArrayInitialValue = wx.TextCtrl(id=ID_DATATYPEEDITORARRAYINITIALVALUE, 
              name='ArrayInitialValue', parent=self.ArrayPanel, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TAB_TRAVERSAL|wx.TE_PROCESS_ENTER|wx.TE_MULTILINE|wx.TE_RICH)
        self.Bind(wx.EVT_TEXT_ENTER, self.OnReturnKeyPressed, id=ID_DATATYPEEDITORARRAYINITIALVALUE)
        
        # Panel for Structure data types
        
        self.StructurePanel = wx.Panel(id=ID_DATATYPEEDITORSTRUCTUREPANEL,
              name='StructurePanel', parent=self.Editor, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)
        
        self.staticText11 = wx.StaticText(id=ID_DATATYPEEDITORSTATICTEXT11,
              label=_('Elements :'), name='staticText11', parent=self.StructurePanel,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.StructureElementsGrid = CustomGrid(id=ID_DATATYPEEDITORSTRUCTUREELEMENTSGRID,
              name='StructureElementsGrid', parent=self.StructurePanel, pos=wx.Point(0, 0), 
              size=wx.Size(0, 150), style=wx.VSCROLL)
        if wx.VERSION >= (2, 6, 0):
            self.StructureElementsGrid.Bind(wx.grid.EVT_GRID_CELL_CHANGE, self.OnStructureElementsGridCellChange)
            self.StructureElementsGrid.Bind(wx.grid.EVT_GRID_EDITOR_SHOWN, self.OnStructureElementsGridEditorShown)
        else:
            wx.grid.EVT_GRID_CELL_CHANGE(self.StructureElementsGrid, self.OnStructureElementsGridCellChange)
            wx.grid.EVT_GRID_EDITOR_SHOWN(self.StructureElementsGrid, self.OnStructureElementsGridEditorShown)
        
        self.StructureAddButton = wx.Button(id=ID_DATATYPEEDITORSTRUCTUREADDBUTTON, label=_('Add'),
              name='StructureAddButton', parent=self.StructurePanel, pos=wx.Point(0, 0),
              size=wx.DefaultSize, style=0)
        
        self.StructureDeleteButton = wx.Button(id=ID_DATATYPEEDITORSTRUCTUREDELETEBUTTON, label=_('Delete'),
              name='StructureDeleteButton', parent=self.StructurePanel, pos=wx.Point(0, 0),
              size=wx.DefaultSize, style=0)
        
        self.StructureUpButton = wx.Button(id=ID_DATATYPEEDITORSTRUCTUREUPBUTTON, label='^',
              name='StructureUpButton', parent=self.StructurePanel, pos=wx.Point(0, 0),
              size=wx.Size(32, 32), style=0)
        
        self.StructureDownButton = wx.Button(id=ID_DATATYPEEDITORSTRUCTUREDOWNBUTTON, label='v',
              name='StructureDownButton', parent=self.StructurePanel, pos=wx.Point(0, 0),
              size=wx.Size(32, 32), style=0)
        
        self._init_sizers()

    def __init__(self, parent, tagname, window, controler):
        EditorPanel.__init__(self, parent, tagname, window, controler)
        
        self.StructureElementDefaultValue = {"Name" : "", "Type" : "INT", "Initial Value" : ""}
        self.StructureElementsTable = ElementsTable(self, [], GetElementsTableColnames())
        self.StructureColSizes = [40, 150, 100, 250]
        self.StructureColAlignements = [wx.ALIGN_CENTER, wx.ALIGN_LEFT, wx.ALIGN_LEFT, wx.ALIGN_LEFT]
        
        self.StructureElementsGrid.SetTable(self.StructureElementsTable)
        self.StructureElementsGrid.SetButtons({"Add": self.StructureAddButton,
                                               "Delete": self.StructureDeleteButton,
                                               "Up": self.StructureUpButton,
                                               "Down": self.StructureDownButton})
        
        def _AddStructureElement(new_row):
            self.StructureElementsTable.InsertRow(new_row, self.StructureElementDefaultValue.copy())
            self.RefreshTypeInfos()
            self.StructureElementsTable.ResetView(self.StructureElementsGrid)
            return new_row
        setattr(self.StructureElementsGrid, "_AddRow", _AddStructureElement)
        
        def _DeleteStructureElement(row):
            self.StructureElementsTable.RemoveRow(row)
            self.RefreshTypeInfos()
            self.StructureElementsTable.ResetView(self.StructureElementsGrid)
        setattr(self.StructureElementsGrid, "_DeleteRow", _DeleteStructureElement)
            
        def _MoveStructureElement(row, move):
            new_row = self.StructureElementsTable.MoveRow(row, move)
            if new_row != row:
                self.RefreshTypeInfos()
                self.StructureElementsTable.ResetView(self.StructureElementsGrid)
            return new_row
        setattr(self.StructureElementsGrid, "_MoveRow", _MoveStructureElement)
        
        self.StructureElementsGrid.SetRowLabelSize(0)
        for col in range(self.StructureElementsTable.GetNumberCols()):
            attr = wx.grid.GridCellAttr()
            attr.SetAlignment(self.StructureColAlignements[col], wx.ALIGN_CENTRE)
            self.StructureElementsGrid.SetColAttr(col, attr)
            self.StructureElementsGrid.SetColMinimalWidth(col, self.StructureColSizes[col])
            self.StructureElementsGrid.AutoSizeColumn(col, False)
        self.StructureElementsGrid.RefreshButtons()
        
        for datatype in GetDatatypeTypes():
            self.DerivationType.Append(_(datatype))
        self.SubrangePanel.Hide()
        self.EnumeratedPanel.Hide()
        self.ArrayPanel.Hide()
        self.StructurePanel.Hide()
        self.CurrentPanel = "Directly"
        self.Highlights = []
        self.Initializing = False
        
        self.HighlightControls = {
            ("Directly", "base"): self.DirectlyBaseType,
            ("Directly", "initial"): self.DirectlyInitialValue,
            ("Subrange", "base"): self.SubrangeBaseType,
            ("Subrange", "lower"): self.SubrangeMinimum,
            ("Subrange", "upper"): self.SubrangeMaximum,
            ("Subrange", "initial"): self.SubrangeInitialValue,
            ("Enumerated", "value"): self.EnumeratedValues,
            ("Enumerated", "initial"): self.EnumeratedInitialValue,
            ("Array", "initial"): self.ArrayInitialValue,
            ("Array", "base"): self.ArrayBaseType,
            ("Array", "range"): self.ArrayDimensions,
        }
        
        self.RefreshHighlightsTimer = wx.Timer(self, -1)
        self.Bind(wx.EVT_TIMER, self.OnRefreshHighlightsTimer, self.RefreshHighlightsTimer)
        
    def __del__(self):
        self.RefreshHighlightsTimer.Stop()
    
    def GetBufferState(self):
        return self.Controler.GetBufferState()
        
    def Undo(self):
        self.Controler.LoadPrevious()
        self.ParentWindow.CloseTabsWithoutModel()
            
    def Redo(self):
        self.Controler.LoadNext()
        self.ParentWindow.CloseTabsWithoutModel()
    
    def HasNoModel(self):
        return self.Controler.GetEditedElement(self.TagName) is None
        
    def RefreshView(self):
        self.Initializing = True
        self.DirectlyBaseType.Clear()
        self.ArrayBaseType.Clear()
        for datatype in self.Controler.GetDataTypes(self.TagName):
            self.DirectlyBaseType.Append(datatype)
            self.ArrayBaseType.Append(datatype)
        self.DirectlyBaseType.SetSelection(0)
        self.SubrangeBaseType.Clear()
        words = self.TagName.split("::")
        for base_type in self.Controler.GetSubrangeBaseTypes(words[1]):
            self.SubrangeBaseType.Append(base_type)
        self.SubrangeBaseType.SetSelection(0)
        self.RefreshBoundsRange()
        type_infos = self.Controler.GetDataTypeInfos(self.TagName)
        if type_infos is not None:
            datatype = type_infos["type"]
            self.DerivationType.SetStringSelection(_(datatype))
            if type_infos["type"] == "Directly":
                self.DirectlyBaseType.SetStringSelection(type_infos["base_type"])
                self.DirectlyInitialValue.SetValue(type_infos["initial"])
            elif type_infos["type"] == "Subrange":
                self.SubrangeBaseType.SetStringSelection(type_infos["base_type"])
                self.RefreshBoundsRange()
                self.SubrangeMinimum.SetValue(int(type_infos["min"]))
                self.SubrangeMaximum.SetValue(int(type_infos["max"]))
                self.RefreshSubrangeInitialValueRange()
                if type_infos["initial"] != "":
                    self.SubrangeInitialValue.SetValue(int(type_infos["initial"]))
                else:
                    self.SubrangeInitialValue.SetValue(type_infos["min"])
            elif type_infos["type"] == "Enumerated":
                self.EnumeratedValues.SetStrings(type_infos["values"])
                self.RefreshEnumeratedValues()
                self.EnumeratedInitialValue.SetStringSelection(type_infos["initial"])
            elif type_infos["type"] == "Array":
                self.ArrayBaseType.SetStringSelection(type_infos["base_type"])
                self.ArrayDimensions.SetStrings(map(lambda x : "..".join(x), type_infos["dimensions"]))
                self.ArrayInitialValue.SetValue(type_infos["initial"])
            elif type_infos["type"] == "Structure":
                self.StructureElementsTable.SetData(type_infos["elements"])
            self.RefreshDisplayedInfos()
        self.ShowHighlights()
        self.StructureElementsTable.ResetView(self.StructureElementsGrid)
        self.StructureElementsGrid.RefreshButtons()
        self.Initializing = False
    
    def OnDerivationTypeChanged(self, event):
        wx.CallAfter(self.RefreshDisplayedInfos)
        wx.CallAfter(self.RefreshTypeInfos)
        event.Skip()

    def OnReturnKeyPressed(self, event):
        self.RefreshTypeInfos()
        
    def OnInfosChanged(self, event):
        self.RefreshTypeInfos()
        event.Skip()

    def OnSubrangeBaseTypeChanged(self, event):
        self.RefreshBoundsRange()
        self.RefreshTypeInfos()
        event.Skip()

    def OnSubrangeMinimumChanged(self, event):
        if not self.Initializing:
            wx.CallAfter(self.SubrangeMinimum.SetValue, min(self.SubrangeMaximum.GetValue(), self.SubrangeMinimum.GetValue()))
            wx.CallAfter(self.RefreshSubrangeInitialValueRange)
            wx.CallAfter(self.RefreshTypeInfos)
        event.Skip()

    def OnSubrangeMaximumChanged(self, event):
        if not self.Initializing:
            wx.CallAfter(self.SubrangeMaximum.SetValue, max(self.SubrangeMinimum.GetValue(), self.SubrangeMaximum.GetValue()))
            wx.CallAfter(self.RefreshSubrangeInitialValueRange)
            wx.CallAfter(self.RefreshTypeInfos)
        event.Skip()

    def OnDimensionsChanged(self, event):
        wx.CallAfter(self.RefreshTypeInfos)
        event.Skip()

    def OnEnumeratedValueEndEdit(self, event):
        text = event.GetText()
        values = self.EnumeratedValues.GetStrings()
        index = event.GetIndex()
        if index >= len(values) or values[index].upper() != text.upper():
            if text.upper() in [value.upper() for value in values]:
                message = wx.MessageDialog(self, _("\"%s\" value already defined!")%text, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
                event.Veto()
            elif text.upper() in IEC_KEYWORDS:
                message = wx.MessageDialog(self, _("\"%s\" is a keyword. It can't be used!")%text, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
            else:
                initial_selected = None
                if index < len(values) and self.EnumeratedInitialValue.GetStringSelection() == values[index]:
                    initial_selected = text
                wx.CallAfter(self.RefreshEnumeratedValues, initial_selected)
                wx.CallAfter(self.RefreshTypeInfos)
                event.Skip()
        else:
            event.Skip()
    
    def OnEnumeratedValuesChanged(self, event):
        wx.CallAfter(self.RefreshEnumeratedValues)
        wx.CallAfter(self.RefreshTypeInfos)
        event.Skip()
    
    def OnStructureElementsGridCellChange(self, event):
        row, col = event.GetRow(), event.GetCol()
        colname = self.StructureElementsTable.GetColLabelValue(col)
        value = self.StructureElementsTable.GetValue(row, col)
        if colname == "Name":
            if not TestIdentifier(value):
                message = wx.MessageDialog(self, _("\"%s\" is not a valid identifier!")%value, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
                event.Veto()
            elif value.upper() in IEC_KEYWORDS:
                message = wx.MessageDialog(self, _("\"%s\" is a keyword. It can't be used!")%value, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
                event.Veto()
##            elif value.upper() in self.PouNames:
##                message = wx.MessageDialog(self, "A pou with \"%s\" as name exists!"%value, "Error", wx.OK|wx.ICON_ERROR)
##                message.ShowModal()
##                message.Destroy()
##                event.Veto()
            elif value.upper() in [var["Name"].upper() for idx, var in enumerate(self.StructureElementsTable.GetData()) if idx != row]:
                message = wx.MessageDialog(self, _("An element named \"%s\" already exists in this structure!")%value, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
                event.Veto()
            else:
                self.RefreshTypeInfos()
                wx.CallAfter(self.StructureElementsTable.ResetView, self.StructureElementsGrid)
##                old_value = self.Table.GetOldValue()
##                if old_value != "":
##                    self.Controler.UpdateEditedElementUsedVariable(self.TagName, old_value, value)
##                self.Controler.BufferProject()
                event.Skip()
        else:
            self.RefreshTypeInfos()
            wx.CallAfter(self.StructureElementsTable.ResetView, self.StructureElementsGrid)
            event.Skip()
    
    def OnStructureElementsGridSelectCell(self, event):
        wx.CallAfter(self.RefreshStructureButtons)
        event.Skip()
    
    def OnStructureElementsGridEditorShown(self, event):
        row, col = event.GetRow(), event.GetCol() 
        if self.StructureElementsTable.GetColLabelValue(col) == "Type":
            type_menu = wx.Menu(title='')
            base_menu = wx.Menu(title='')
            for base_type in self.Controler.GetBaseTypes():
                new_id = wx.NewId()
                AppendMenu(base_menu, help='', id=new_id, kind=wx.ITEM_NORMAL, text=base_type)
                self.Bind(wx.EVT_MENU, self.GetElementTypeFunction(base_type), id=new_id)
            type_menu.AppendMenu(wx.NewId(), _("Base Types"), base_menu)
            datatype_menu = wx.Menu(title='')
            for datatype in self.Controler.GetDataTypes(self.TagName, False):
                new_id = wx.NewId()
                AppendMenu(datatype_menu, help='', id=new_id, kind=wx.ITEM_NORMAL, text=datatype)
                self.Bind(wx.EVT_MENU, self.GetElementTypeFunction(datatype), id=new_id)
            type_menu.AppendMenu(wx.NewId(), _("User Data Types"), datatype_menu)
##            functionblock_menu = wx.Menu(title='')
##            bodytype = self.Controler.GetEditedElementBodyType(self.TagName)
##            pouname, poutype = self.Controler.GetEditedElementType(self.TagName)
##            if classtype in ["Input","Output","InOut","External","Global"] or poutype != "function" and bodytype in ["ST", "IL"]:
##                for functionblock_type in self.Controler.GetFunctionBlockTypes(self.TagName):
##                    new_id = wx.NewId()
##                    AppendMenu(functionblock_menu, help='', id=new_id, kind=wx.ITEM_NORMAL, text=functionblock_type)
##                    self.Bind(wx.EVT_MENU, self.GetVariableTypeFunction(functionblock_type), id=new_id)
##                type_menu.AppendMenu(wx.NewId(), _("Function Block Types"), functionblock_menu)
            rect = self.StructureElementsGrid.BlockToDeviceRect((row, col), (row, col))
            self.StructureElementsGrid.PopupMenuXY(type_menu, rect.x + rect.width, rect.y + self.StructureElementsGrid.GetColLabelSize())
            type_menu.Destroy()
            event.Veto()
        else:
            event.Skip()

    def GetElementTypeFunction(self, base_type):
        def ElementTypeFunction(event):
            row = self.StructureElementsGrid.GetGridCursorRow()
            self.StructureElementsTable.SetValueByName(row, "Type", base_type)
            self.RefreshTypeInfos()
            self.StructureElementsTable.ResetView(self.StructureElementsGrid)
        return ElementTypeFunction

    def RefreshDisplayedInfos(self):
        selected = DATATYPE_TYPES_DICT[self.DerivationType.GetStringSelection()]
        if selected != self.CurrentPanel:
            if self.CurrentPanel == "Directly":
                self.DirectlyPanel.Hide()
            elif self.CurrentPanel == "Subrange":
                self.SubrangePanel.Hide()
            elif self.CurrentPanel == "Enumerated":
                self.EnumeratedPanel.Hide()
            elif self.CurrentPanel == "Array":
                self.ArrayPanel.Hide()
            elif self.CurrentPanel == "Structure":
                self.StructurePanel.Hide()
            self.CurrentPanel = selected
            if selected == "Directly":
                self.DirectlyPanel.Show()
            elif selected == "Subrange":
                self.SubrangePanel.Show()
            elif selected == "Enumerated":
                self.EnumeratedPanel.Show()
            elif selected == "Array":
                self.ArrayPanel.Show()
            elif selected == "Structure":
                self.StructurePanel.Show()
            self.MainSizer.Layout()

    def RefreshEnumeratedValues(self, initial_selected=None):
        if initial_selected is None:
            initial_selected = self.EnumeratedInitialValue.GetStringSelection()
        self.EnumeratedInitialValue.Clear()
        self.EnumeratedInitialValue.Append("")
        for value in self.EnumeratedValues.GetStrings():
            self.EnumeratedInitialValue.Append(value)
        self.EnumeratedInitialValue.SetStringSelection(initial_selected)

    def RefreshBoundsRange(self):
        range = self.Controler.GetDataTypeRange(self.SubrangeBaseType.GetStringSelection())
        if range is not None:
            min_value, max_value = range
            self.SubrangeMinimum.SetRange(min_value, max_value)
            self.SubrangeMinimum.SetValue(min(max(min_value, self.SubrangeMinimum.GetValue()), max_value))
            self.SubrangeMaximum.SetRange(min_value, max_value)
            self.SubrangeMaximum.SetValue(min(max(min_value, self.SubrangeMaximum.GetValue()), max_value))

    def RefreshSubrangeInitialValueRange(self):
        self.SubrangeInitialValue.SetRange(self.SubrangeMinimum.GetValue(), self.SubrangeMaximum.GetValue())

    def RefreshTypeInfos(self):
        selected = DATATYPE_TYPES_DICT[self.DerivationType.GetStringSelection()]
        infos = {"type" : selected}
        if selected == "Directly":
            infos["base_type"] = self.DirectlyBaseType.GetStringSelection()
            infos["initial"] = self.DirectlyInitialValue.GetValue()
        elif selected == "Subrange":
            infos["base_type"] = self.SubrangeBaseType.GetStringSelection()
            infos["min"] = str(self.SubrangeMinimum.GetValue())
            infos["max"] = str(self.SubrangeMaximum.GetValue())
            initial_value = self.SubrangeInitialValue.GetValue()
            if initial_value == infos["min"]:
                infos["initial"] = ""
            else:
                infos["initial"] = str(initial_value)
        elif selected == "Enumerated":
            infos["values"] = self.EnumeratedValues.GetStrings()
            infos["initial"] = self.EnumeratedInitialValue.GetStringSelection()
        elif selected == "Array":
            infos["base_type"] = self.ArrayBaseType.GetStringSelection()
            infos["dimensions"] = []
            for dimensions in self.ArrayDimensions.GetStrings():
                result = DIMENSION_MODEL.match(dimensions)
                if result is None:
                    message = wx.MessageDialog(self, _("\"%s\" value isn't a valid array dimension!")%dimensions, _("Error"), wx.OK|wx.ICON_ERROR)
                    message.ShowModal()
                    message.Destroy()
                    self.RefreshView()
                    return
                bounds = result.groups()
                if int(bounds[0]) >= int(bounds[1]):
                    message = wx.MessageDialog(self, _("\"%s\" value isn't a valid array dimension!\nRight value must be greater than left value.")%dimensions, _("Error"), wx.OK|wx.ICON_ERROR)
                    message.ShowModal()
                    message.Destroy()
                    self.RefreshView()
                    return
                infos["dimensions"].append(bounds)
            infos["initial"] = self.ArrayInitialValue.GetValue()
        elif selected == "Structure":
            infos["elements"] = self.StructureElementsTable.GetData()
            infos["initial"] = ""
        self.Controler.SetDataTypeInfos(self.TagName, infos)
        self.ParentWindow.RefreshTitle()
        self.ParentWindow.RefreshFileMenu()
        self.ParentWindow.RefreshEditMenu()

#-------------------------------------------------------------------------------
#                        Highlights showing functions
#-------------------------------------------------------------------------------

    def OnRefreshHighlightsTimer(self, event):
        self.RefreshView()
        event.Skip()

    def ClearHighlights(self, highlight_type=None):
        if highlight_type is None:
            self.Highlights = []
        else:
            self.Highlights = [(infos, start, end, highlight) for (infos, start, end, highlight) in self.Highlights if highlight != highlight_type]
        for control in self.HighlightControls.itervalues():
            if isinstance(control, (wx.ComboBox, wx.SpinCtrl)):
                control.SetBackgroundColour(wx.NullColour)
                control.SetForegroundColour(wx.NullColour)
            elif isinstance(control, wx.TextCtrl):
                value = control.GetValue()
                control.SetStyle(0, len(value), wx.TextAttr(wx.NullColour))
            elif isinstance(control, wx.gizmos.EditableListBox):
                listctrl = control.GetListCtrl()
                for i in xrange(listctrl.GetItemCount()):
                    listctrl.SetItemBackgroundColour(i, wx.NullColour)
                    listctrl.SetItemTextColour(i, wx.NullColour)
        self.StructureElementsTable.ClearHighlights(highlight_type)
        self.RefreshView()

    def AddHighlight(self, infos, start, end ,highlight_type):
        self.Highlights.append((infos, start, end, highlight_type))
        self.RefreshHighlightsTimer.Start(int(REFRESH_HIGHLIGHT_PERIOD * 1000), oneShot=True)

    def ShowHighlights(self):
        type_infos = self.Controler.GetDataTypeInfos(self.TagName)
        for infos, start, end, highlight_type in self.Highlights:
            if infos[0] == "struct":
                self.StructureElementsTable.AddHighlight(infos[1:], highlight_type)
            else:
                control = self.HighlightControls.get((type_infos["type"], infos[0]), None)
                if control is not None:
                    if isinstance(control, (wx.ComboBox, wx.SpinCtrl)):
                        control.SetBackgroundColour(highlight_type[0])
                        control.SetForegroundColour(highlight_type[1])
                    elif isinstance(control, wx.TextCtrl):
                        control.SetStyle(start[1], end[1] + 1, wx.TextAttr(highlight_type[1], highlight_type[0]))
                    elif isinstance(control, wx.gizmos.EditableListBox):
                        listctrl = control.GetListCtrl()
                        listctrl.SetItemBackgroundColour(infos[1], highlight_type[0])
                        listctrl.SetItemTextColour(infos[1], highlight_type[1])
                        listctrl.Select(listctrl.FocusedItem, False)

