#!/usr/bin/env python
# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import re

import wx

RE_ESCAPED_CHARACTERS = ".*+()[]?:|{}^$<>=-,"

def EscapeText(text):
    text = text.replace('\\', '\\\\')
    for c in RE_ESCAPED_CHARACTERS:
        text = text.replace(c, '\\' + c)
    return text

#-------------------------------------------------------------------------------
#                          Search In Project Dialog
#-------------------------------------------------------------------------------

def GetElementsChoices():
    _ = lambda x: x
    return [("datatype", _("Data Type")), 
            ("function", _("Function")), 
            ("functionBlock", _("Function Block")), 
            ("program", _("Program")), 
            ("configuration", _("Configuration"))]

[ID_SEARCHINPROJECTDIALOG, ID_SEARCHINPROJECTDIALOGPATTERNLABEL, 
 ID_SEARCHINPROJECTDIALOGPATTERN, ID_SEARCHINPROJECTDIALOGCASESENSITIVE,
 ID_SEARCHINPROJECTDIALOGREGULAREXPRESSION, ID_SEARCHINPROJECTDIALOGSCOPESTATICBOX, 
 ID_SEARCHINPROJECTDIALOGWHOLEPROJECT, ID_SEARCHINPROJECTDIALOGONLYELEMENTS,
 ID_SEARCHINPROJECTDIALOGELEMENTSLIST,
] = [wx.NewId() for _init_ctrls in range(9)]

class SearchInProjectDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.PatternSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ScopeSizer, 0, border=20, flag=wx.GROW|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)

    def _init_coll_MainSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)
    
    def _init_coll_PatternSizer_Items(self, parent):
        parent.AddWindow(self.PatternLabel, 0, border=0, flag=wx.ALIGN_BOTTOM)
        parent.AddWindow(self.CaseSensitive, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Pattern, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.RegularExpression, 0, border=0, flag=wx.GROW)

    def _init_coll_PatternSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
    
    def _init_coll_ScopeSizer_Items(self, parent):
        parent.AddSizer(self.ScopeSelectionSizer, 1, border=5, flag=wx.GROW|wx.TOP|wx.LEFT|wx.BOTTOM)
        parent.AddWindow(self.ElementsList, 1, border=5, flag=wx.GROW|wx.TOP|wx.RIGHT|wx.BOTTOM)
    
    def _init_coll_ScopeSelectionSizer_Items(self, parent):
        parent.AddWindow(self.WholeProject, 0, border=5, flag=wx.GROW|wx.BOTTOM)
        parent.AddWindow(self.OnlyElements, 0, border=0, flag=wx.GROW)
    
    def _init_sizers(self):
        self.MainSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=3, vgap=10)
        self.PatternSizer = wx.FlexGridSizer(cols=2, hgap=5, rows=2, vgap=5)
        self.ScopeSizer = wx.StaticBoxSizer(self.ScopeStaticBox, wx.HORIZONTAL)
        self.ScopeSelectionSizer = wx.BoxSizer(wx.VERTICAL)
        
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_MainSizer_Growables(self.MainSizer)
        self._init_coll_PatternSizer_Items(self.PatternSizer)
        self._init_coll_PatternSizer_Growables(self.PatternSizer)
        self._init_coll_ScopeSizer_Items(self.ScopeSizer)
        self._init_coll_ScopeSelectionSizer_Items(self.ScopeSelectionSizer)
        
        self.SetSizer(self.MainSizer)
    
    def _init_ctrls(self, prnt):
        wx.Dialog.__init__(self, id=ID_SEARCHINPROJECTDIALOG,
              name='SearchInProjectDialog', parent=prnt,
              size=wx.Size(600, 300), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER,
              title=_('Search in Project'))
        
        self.PatternLabel = wx.StaticText(id=ID_SEARCHINPROJECTDIALOGPATTERNLABEL,
              label=_('Pattern to search:'), name='PatternLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.Pattern = wx.TextCtrl(id=ID_SEARCHINPROJECTDIALOGPATTERN,
              name='Pattern', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=0)

        self.CaseSensitive = wx.CheckBox(id=ID_SEARCHINPROJECTDIALOGCASESENSITIVE,
              label=_('Case sensitive'), name='CaseSensitive', parent=self, 
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)
        
        self.RegularExpression = wx.CheckBox(id=ID_SEARCHINPROJECTDIALOGREGULAREXPRESSION,
              label=_('Regular expression'), name='RegularExpression', parent=self, 
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)
        
        self.ScopeStaticBox = wx.StaticBox(id=ID_SEARCHINPROJECTDIALOGSCOPESTATICBOX,
              label=_('Scope'), name='ScopeStaticBox', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 0), style=0)
        
        self.WholeProject = wx.RadioButton(id=ID_SEARCHINPROJECTDIALOGWHOLEPROJECT,
              label=_('Whole Project'), name='WholeProject', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=wx.RB_GROUP)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnScopeChanged, id=ID_SEARCHINPROJECTDIALOGWHOLEPROJECT)
        self.WholeProject.SetValue(True)
        
        self.OnlyElements = wx.RadioButton(id=ID_SEARCHINPROJECTDIALOGONLYELEMENTS,
              label=_('Only Elements'), name='OnlyElements', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnScopeChanged, id=ID_SEARCHINPROJECTDIALOGONLYELEMENTS)
        self.OnlyElements.SetValue(False)
        
        self.ElementsList = wx.CheckListBox(id=ID_SEARCHINPROJECTDIALOGELEMENTSLIST,
              name='ElementsList', parent=self, pos=wx.Point(0, 0), 
              size=wx.Size(0, 0), style=0)
        self.ElementsList.Enable(False)
        
        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            ok_button = self.ButtonSizer.GetAffirmativeButton()
        else:
            ok_button = self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow()
        ok_button.SetLabel(_('Search'))
        self.Bind(wx.EVT_BUTTON, self.OnOK, id=ok_button.GetId())
        
        self._init_sizers()

    def __init__(self, parent):
        self._init_ctrls(parent)

        for name, label in GetElementsChoices():
            self.ElementsList.Append(_(label))
        
        self.Pattern.SetFocus()

    def GetCriteria(self):
        raw_pattern = pattern = self.Pattern.GetValue()
        if not self.CaseSensitive.GetValue():
            pattern = pattern.upper()
        if not self.RegularExpression.GetValue():
            pattern = EscapeText(pattern)
        criteria = {
            "raw_pattern": raw_pattern, 
            "pattern": re.compile(pattern),
            "case_sensitive": self.CaseSensitive.GetValue(),
            "regular_expression": self.RegularExpression.GetValue(),
        }
        if self.WholeProject.GetValue():
            criteria["filter"] = "all"
        elif self.OnlyElements.GetValue():
            criteria["filter"] = []
            for index, (name, label) in enumerate(GetElementsChoices()):
                if self.ElementsList.IsChecked(index):
                    criteria["filter"].append(name)
        return criteria
    
    def OnScopeChanged(self, event):
        self.ElementsList.Enable(self.OnlyElements.GetValue())
        event.Skip()
    
    def OnOK(self, event):
        if self.Pattern.GetValue() == "":
            message = wx.MessageDialog(self, _("Form isn't complete. Pattern to search must be filled!"), _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        else:
            wrong_pattern = False
            if self.RegularExpression.GetValue():
                try:
                    re.compile(self.Pattern.GetValue())
                except:
                    wrong_pattern = True
            if wrong_pattern:
                message = wx.MessageDialog(self, _("Syntax error in regular expression of pattern to search!"), _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
            else:
                self.EndModal(wx.ID_OK)
