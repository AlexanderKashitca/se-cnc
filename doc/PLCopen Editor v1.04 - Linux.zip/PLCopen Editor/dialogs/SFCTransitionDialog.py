# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx

from graphics import *

#-------------------------------------------------------------------------------
#                          Edit Transition Content Dialog
#-------------------------------------------------------------------------------

[ID_SFCTRANSITIONDIALOG, ID_SFCTRANSITIONDIALOGSPACER, 
 ID_SFCTRANSITIONDIALOGREFERENCE, ID_SFCTRANSITIONDIALOGINLINE, 
 ID_SFCTRANSITIONDIALOGPRIORITY, ID_SFCTRANSITIONDIALOGPREVIEW, 
 ID_SFCTRANSITIONDIALOGRADIOBUTTON1, ID_SFCTRANSITIONDIALOGRADIOBUTTON2, 
 ID_SFCTRANSITIONDIALOGRADIOBUTTON3, ID_SFCTRANSITIONDIALOGSTATICTEXT1, 
 ID_SFCTRANSITIONDIALOGSTATICTEXT2, ID_SFCTRANSITIONDIALOGSTATICTEXT3, 
] = [wx.NewId() for _init_ctrls in range(12)]

class SFCTransitionDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.MainSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)
        
    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.LeftGridSizer, 1, border=5, flag=wx.GROW|wx.RIGHT)
        parent.AddSizer(self.RightGridSizer, 1, border=5, flag=wx.GROW|wx.LEFT)
    
    def _init_coll_LeftGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Reference, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Inline, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Priority, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Spacer, 0, border=0, flag=wx.GROW)
    
    def _init_coll_LeftGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(6)
            
    def _init_coll_RightGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Preview, 0, border=0, flag=wx.GROW)
        
    def _init_coll_RightGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)

    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.MainSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.LeftGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=9, vgap=5)
        self.RightGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=5)

        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_LeftGridSizer_Items(self.LeftGridSizer)
        self._init_coll_LeftGridSizer_Growables(self.LeftGridSizer)
        self._init_coll_RightGridSizer_Items(self.RightGridSizer)
        self._init_coll_RightGridSizer_Growables(self.RightGridSizer)

        self.SetSizer(self.flexGridSizer1)

    def _init_ctrls(self, prnt, ctrler):
        wx.Dialog.__init__(self, id=ID_SFCTRANSITIONDIALOG,
              name='SFCTransitionDialog', parent=prnt,
              size=wx.Size(350, 300), style=wx.DEFAULT_DIALOG_STYLE,
              title=_('Edit transition'))
        self.SetClientSize(wx.Size(350, 300))

        self.staticText1 = wx.StaticText(id=ID_SFCTRANSITIONDIALOGSTATICTEXT1,
              label=_('Type:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText2 = wx.StaticText(id=ID_SFCTRANSITIONDIALOGSTATICTEXT2,
              label=_('Preview:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText3 = wx.StaticText(id=ID_SFCTRANSITIONDIALOGSTATICTEXT3,
              label=_('Priority:'), name='staticText3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.radioButton1 = wx.RadioButton(id=ID_SFCTRANSITIONDIALOGRADIOBUTTON1,
              label=_('Reference'), name='radioButton1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=wx.RB_GROUP)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCTRANSITIONDIALOGRADIOBUTTON1)
        self.radioButton1.SetValue(True)

        self.Reference = wx.ComboBox(id=ID_SFCTRANSITIONDIALOGREFERENCE,
              name='Reference', parent=self, pos=wx.Point(0, 0), 
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnReferenceChanged, id=ID_SFCTRANSITIONDIALOGREFERENCE)

        self.radioButton2 = wx.RadioButton(id=ID_SFCTRANSITIONDIALOGRADIOBUTTON2,
              label=_('Inline'), name='radioButton2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCTRANSITIONDIALOGRADIOBUTTON2)
        self.radioButton2.SetValue(False)

        self.Inline = wx.TextCtrl(id=ID_SFCTRANSITIONDIALOGINLINE,
              name='Inline', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_TEXT, self.OnInlineChanged, id=ID_SFCTRANSITIONDIALOGINLINE)
        self.Inline.Enable(False)
        
        self.radioButton3 = wx.RadioButton(id=ID_SFCTRANSITIONDIALOGRADIOBUTTON3,
              label=_('Connection'), name='radioButton3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCTRANSITIONDIALOGRADIOBUTTON3)
        self.radioButton3.SetValue(False)
        if not self.Connection:
            self.radioButton3.Hide()

        self.Priority = wx.SpinCtrl(id=ID_SFCTRANSITIONDIALOGPRIORITY,
              name='Priority', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.SP_ARROW_KEYS, min=0)
        self.Bind(wx.EVT_TEXT, self.OnPriorityChanged, id=ID_SFCTRANSITIONDIALOGPRIORITY)

        self.Preview = wx.Panel(id=ID_SFCTRANSITIONDIALOGPREVIEW,
              name='Preview', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL|wx.SIMPLE_BORDER)
        self.Preview.SetBackgroundColour(wx.Colour(255,255,255))
        setattr(self.Preview, "GetDrawingMode", lambda:FREEDRAWING_MODE)
        setattr(self.Preview, "RefreshTransitionModel", lambda x:None)
        setattr(self.Preview, "GetScaling", lambda:None)
        setattr(self.Preview, "IsOfType", ctrler.IsOfType)

        self.Spacer = wx.Panel(id=ID_SFCTRANSITIONDIALOGSPACER,
              name='Spacer', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetAffirmativeButton().GetId())
            self.Preview.Bind(wx.EVT_PAINT, self.OnPaint)
        else:
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow().GetId())
            wx.EVT_PAINT(self.Preview, self.OnPaint)
        
        self._init_sizers()

    def __init__(self, parent, controler, connection):
        self.Connection = connection
        self._init_ctrls(parent, controler)
        self.Transition = None
        self.MinTransitionSize = None
        
        self.Element = SFC_Transition(self.Preview)
        
        self.radioButton1.SetFocus()
    
    def SetPreviewFont(self, font):
        self.Preview.SetFont(font)
    
    def SetElementSize(self, size):
        min_width, min_height = self.Element.GetMinSize()
        width, height = max(min_width, size[0]), max(min_height, size[1])
        self.Element.SetSize(width, height)
    
    def OnOK(self, event):
        error = []
        if self.radioButton1.GetValue() and self.Reference.GetStringSelection() == "":
            error.append(_("Reference"))
        if self.radioButton2.GetValue() and self.Inline.GetValue() == "":
            error.append(_("Inline"))
        if len(error) > 0:
            text = ""
            for i, item in enumerate(error):
                if i == 0:
                    text += item
                elif i == len(error) - 1:
                    text += _(" and %s")%item
                else:
                    text += _(", %s")%item 
            message = wx.MessageDialog(self, _("Form isn't complete. %s must be filled!")%text, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        else:
            self.EndModal(wx.ID_OK)

    def OnTypeChanged(self, event):
        if self.radioButton1.GetValue():
            self.Element.SetType("reference", self.Reference.GetStringSelection())
            self.Reference.Enable(True)
            self.Inline.Enable(False)
        elif self.radioButton2.GetValue():
            self.Element.SetType("inline", self.Inline.GetValue())
            self.Reference.Enable(False)
            self.Inline.Enable(True)
        else:
            self.Element.SetType("connection")
            self.Reference.Enable(False)
            self.Inline.Enable(False)
        self.RefreshPreview()
        event.Skip()

    def OnReferenceChanged(self, event):
        self.Element.SetType("reference", self.Reference.GetStringSelection())
        self.RefreshPreview()
        event.Skip()

    def OnInlineChanged(self, event):
        self.Element.SetType("inline", self.Inline.GetValue())
        self.RefreshPreview()
        event.Skip()

    def OnPriorityChanged(self, event):
        self.Element.SetPriority(int(self.Priority.GetValue()))
        self.RefreshPreview()
        event.Skip()

    def SetTransitions(self, transitions):
        self.Reference.Append("")
        for transition in transitions:
            self.Reference.Append(transition)

    def SetValues(self, values):
        if values["type"] == "reference":
            self.radioButton1.SetValue(True)
            self.radioButton2.SetValue(False)
            self.radioButton3.SetValue(False)
            self.Reference.Enable(True)
            self.Inline.Enable(False)
            self.Reference.SetStringSelection(values["value"])
            self.Element.SetType("reference", values["value"])
        elif values["type"] == "inline":
            self.radioButton1.SetValue(False)
            self.radioButton2.SetValue(True)
            self.radioButton3.SetValue(False)
            self.Reference.Enable(False)
            self.Inline.Enable(True)
            self.Inline.SetValue(values["value"])
            self.Element.SetType("inline", values["value"])
        elif values["type"] == "connection" and self.Connection:
            self.radioButton1.SetValue(False)
            self.radioButton2.SetValue(False)
            self.radioButton3.SetValue(True)
            self.Reference.Enable(False)
            self.Inline.Enable(False)
            self.Element.SetType("connection")
        self.Priority.SetValue(values["priority"])
        self.Element.SetPriority(values["priority"])
        self.RefreshPreview()
        
    def GetValues(self):
        values = {"priority" : int(self.Priority.GetValue())}
        if self.radioButton1.GetValue():
            values["type"] = "reference"
            values["value"] = self.Reference.GetStringSelection()
        elif self.radioButton2.GetValue():
            values["type"] = "inline"
            values["value"] = self.Inline.GetValue()
        else:
            values["type"] = "connection"
            values["value"] = None
        return values

    def RefreshPreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.SetFont(self.Preview.GetFont())
        dc.Clear()
        clientsize = self.Preview.GetClientSize()
        posx, posy = self.Element.GetPosition()
        rect = self.Element.GetBoundingBox()
        diffx, diffy = posx - rect.x, posy - rect.y
        self.Element.SetPosition((clientsize.width - rect.width) / 2 + diffx, (clientsize.height - rect.height) / 2 + diffy)
        self.Element.Draw(dc)

    def OnPaint(self, event):
        self.RefreshPreview()
        event.Skip()
