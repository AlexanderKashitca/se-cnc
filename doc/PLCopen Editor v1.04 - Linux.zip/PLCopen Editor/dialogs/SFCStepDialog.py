# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx

from graphics import *

#-------------------------------------------------------------------------------
#                          Edit Step Content Dialog
#-------------------------------------------------------------------------------

[ID_SFCSTEPDIALOG, ID_SFCSTEPDIALOGSPACER, 
 ID_SFCSTEPDIALOGNAME, ID_SFCSTEPDIALOGPREVIEW, 
 ID_SFCSTEPDIALOGCHECKBOX1, ID_SFCSTEPDIALOGCHECKBOX2,
 ID_SFCSTEPDIALOGCHECKBOX3, ID_SFCSTEPDIALOGSTATICTEXT1, 
 ID_SFCSTEPDIALOGSTATICTEXT2, ID_SFCSTEPDIALOGSTATICTEXT3, 
] = [wx.NewId() for _init_ctrls in range(10)]

class SFCStepDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.MainSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)
        
    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.LeftGridSizer, 1, border=5, flag=wx.GROW|wx.RIGHT)
        parent.AddSizer(self.RightGridSizer, 1, border=5, flag=wx.GROW|wx.LEFT)
    
    def _init_coll_LeftGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.StepName, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.checkBox1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.checkBox2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.checkBox3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Spacer, 0, border=0, flag=wx.GROW)
        
    def _init_coll_LeftGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(6)
            
    def _init_coll_RightGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Preview, 0, border=0, flag=wx.GROW)
        
    def _init_coll_RightGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)

    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.MainSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.LeftGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=7, vgap=5)
        self.RightGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=5)

        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_LeftGridSizer_Items(self.LeftGridSizer)
        self._init_coll_LeftGridSizer_Growables(self.LeftGridSizer)
        self._init_coll_RightGridSizer_Items(self.RightGridSizer)
        self._init_coll_RightGridSizer_Growables(self.RightGridSizer)

        self.SetSizer(self.flexGridSizer1)

    def _init_ctrls(self, prnt, ctrler):
        wx.Dialog.__init__(self, id=ID_SFCSTEPDIALOG,
              name='SFCStepDialog', parent=prnt,
              size=wx.Size(400, 250), style=wx.DEFAULT_DIALOG_STYLE,
              title=_('Edit Step'))
        self.SetClientSize(wx.Size(400, 250))

        self.staticText1 = wx.StaticText(id=ID_SFCSTEPDIALOGSTATICTEXT1,
              label=_('Name:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText2 = wx.StaticText(id=ID_SFCSTEPDIALOGSTATICTEXT2,
              label=_('Connectors:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText3 = wx.StaticText(id=ID_SFCSTEPDIALOGSTATICTEXT3,
              label=_('Preview:'), name='staticText4', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.StepName = wx.TextCtrl(id=ID_SFCSTEPDIALOGNAME,
              name='Name', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_TEXT, self.OnNameChanged, id=ID_SFCSTEPDIALOGNAME)

        self.checkBox1 = wx.CheckBox(id=ID_SFCSTEPDIALOGCHECKBOX1,
              label=_("Input"), name='checkBox1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_CHECKBOX, self.OnConnectorsChanged, id=ID_SFCSTEPDIALOGCHECKBOX1)
        
        self.checkBox2 = wx.CheckBox(id=ID_SFCSTEPDIALOGCHECKBOX2,
              label=_("Output"), name='checkBox2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_CHECKBOX, self.OnConnectorsChanged, id=ID_SFCSTEPDIALOGCHECKBOX2)
        
        self.checkBox3 = wx.CheckBox(id=ID_SFCSTEPDIALOGCHECKBOX3,
              label=_("Action"), name='checkBox3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_CHECKBOX, self.OnConnectorsChanged, id=ID_SFCSTEPDIALOGCHECKBOX3)
        
        self.Spacer = wx.Panel(id=ID_SFCSTEPDIALOGSPACER,
              name='Spacer', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.Preview = wx.Panel(id=ID_SFCSTEPDIALOGPREVIEW,
              name='Preview', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL|wx.SIMPLE_BORDER)
        self.Preview.SetBackgroundColour(wx.Colour(255,255,255))
        setattr(self.Preview, "GetDrawingMode", lambda:FREEDRAWING_MODE)
        setattr(self.Preview, "RefreshStepModel", lambda x:None)
        setattr(self.Preview, "GetScaling", lambda:None)
        setattr(self.Preview, "IsOfType", ctrler.IsOfType)

        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetAffirmativeButton().GetId())
            self.Preview.Bind(wx.EVT_PAINT, self.OnPaint)
        else:
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow().GetId())
            wx.EVT_PAINT(self.Preview, self.OnPaint)
        
        self._init_sizers()

    def __init__(self, parent, controler, initial = False):
        self._init_ctrls(parent, controler)
        self.Step = None
        self.Initial = initial
        self.MinStepSize = None
    
        self.PouNames = []
        self.Variables = []
        self.StepNames = []
        
        self.StepName.SetFocus()
    
    def SetPreviewFont(self, font):
        self.Preview.SetFont(font)
    
    def OnOK(self, event):
        step_name = self.StepName.GetValue()
        if step_name == "":
            message = wx.MessageDialog(self, _("You must type a name!"), _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif not TestIdentifier(step_name):
            message = wx.MessageDialog(self, _("\"%s\" is not a valid identifier!")%step_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif step_name.upper() in IEC_KEYWORDS:
            message = wx.MessageDialog(self, _("\"%s\" is a keyword. It can't be used!")%step_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif step_name.upper() in self.PouNames:
            message = wx.MessageDialog(self, _("A POU named \"%s\" already exists!")%step_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif step_name.upper() in self.Variables:
            message = wx.MessageDialog(self, _("A variable with \"%s\" as name already exists in this pou!")%step_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif step_name.upper() in self.StepNames:
            message = wx.MessageDialog(self, _("\"%s\" step already exists!")%step_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        else:
            self.EndModal(wx.ID_OK)
    
    def SetMinStepSize(self, size):
        self.MinStepSize = size

    def SetPouNames(self, pou_names):
        self.PouNames = [pou_name.upper() for pou_name in pou_names]

    def SetVariables(self, variables):
        self.Variables = [var["Name"].upper() for var in variables]

    def SetStepNames(self, step_names):
        self.StepNames = [step_name.upper() for step_name in step_names]

    def SetValues(self, values):
        value_name = values.get("name", None)
        if value_name:
            self.StepName.SetValue(value_name)
        else:
            self.StepName.SetValue("")
        self.checkBox1.SetValue(values.get("input", False))
        self.checkBox2.SetValue(values.get("output", False))
        self.checkBox3.SetValue(values.get("action", False))
        self.RefreshPreview()
        
    def GetValues(self):
        values = {}
        values["name"] = self.StepName.GetValue()
        values["input"] = self.checkBox1.IsChecked()
        values["output"] = self.checkBox2.IsChecked()
        values["action"] = self.checkBox3.IsChecked()
        values["width"], values["height"] = self.Step.GetSize()
        return values
    
    def OnConnectorsChanged(self, event):
        self.RefreshPreview()
        event.Skip()

    def OnNameChanged(self, event):
        self.RefreshPreview()
        event.Skip()
    
    def RefreshPreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.SetFont(self.Preview.GetFont())
        dc.Clear()
        self.Step = SFC_Step(self.Preview, self.StepName.GetValue(), self.Initial)
        if self.checkBox1.IsChecked():
            self.Step.AddInput()
        else:
            self.Step.RemoveInput()
        if self.checkBox2.IsChecked():
            self.Step.AddOutput()
        else:
            self.Step.RemoveOutput()
        if self.checkBox3.IsChecked():
            self.Step.AddAction()    
        else:
            self.Step.RemoveAction()
        width, height = self.MinStepSize
        min_width, min_height = self.Step.GetMinSize()
        width, height = max(min_width, width), max(min_height, height)
        self.Step.SetSize(width, height)
        clientsize = self.Preview.GetClientSize()
        x = (clientsize.width - width) / 2
        y = (clientsize.height - height) / 2
        self.Step.SetPosition(x, y)
        self.Step.Draw(dc)

    def OnPaint(self, event):
        self.RefreshPreview()
        event.Skip()
