# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx

from graphics import *

#-------------------------------------------------------------------------------
#                         Create New Divergence Dialog
#-------------------------------------------------------------------------------

[ID_SFCDIVERGENCEDIALOG, ID_SFCDIVERGENCEDIALOGSPACER, 
 ID_SFCDIVERGENCEDIALOGRADIOBUTTON1, ID_SFCDIVERGENCEDIALOGRADIOBUTTON2,
 ID_SFCDIVERGENCEDIALOGRADIOBUTTON3, ID_SFCDIVERGENCEDIALOGRADIOBUTTON4, 
 ID_SFCDIVERGENCEDIALOGSEQUENCES, ID_SFCDIVERGENCEDIALOGPREVIEW, 
 ID_SFCDIVERGENCEDIALOGSTATICTEXT1, ID_SFCDIVERGENCEDIALOGSTATICTEXT2, 
 ID_SFCDIVERGENCEDIALOGSTATICTEXT3,  
] = [wx.NewId() for _init_ctrls in range(11)]

class SFCDivergenceDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.MainSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)
        
    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.LeftGridSizer, 1, border=5, flag=wx.GROW|wx.RIGHT)
        parent.AddSizer(self.RightGridSizer, 1, border=5, flag=wx.GROW|wx.LEFT)
    
    def _init_coll_LeftGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton4, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Sequences, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Spacer, 0, border=0, flag=wx.GROW)
    
    def _init_coll_LeftGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(7)
            
    def _init_coll_RightGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Preview, 0, border=0, flag=wx.GROW)
        
    def _init_coll_RightGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)

    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.MainSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.LeftGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=8, vgap=5)
        self.RightGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=5)

        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_LeftGridSizer_Items(self.LeftGridSizer)
        self._init_coll_LeftGridSizer_Growables(self.LeftGridSizer)
        self._init_coll_RightGridSizer_Items(self.RightGridSizer)
        self._init_coll_RightGridSizer_Growables(self.RightGridSizer)

        self.SetSizer(self.flexGridSizer1)
    
    def _init_ctrls(self, prnt, ctrler):
        wx.Dialog.__init__(self, id=ID_SFCDIVERGENCEDIALOG,
              name='SFCDivergenceDialog', parent=prnt,
              size=wx.Size(500, 300), style=wx.DEFAULT_DIALOG_STYLE,
              title=_('Create a new divergence or convergence'))
        self.SetClientSize(wx.Size(500, 300))

        self.staticText1 = wx.StaticText(id=ID_SFCDIVERGENCEDIALOGSTATICTEXT1,
              label=_('Type:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.radioButton1 = wx.RadioButton(id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON1,
              label=_('Selection Divergence'), name='radioButton1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=wx.RB_GROUP)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON1)
        self.radioButton1.SetValue(True)

        self.radioButton2 = wx.RadioButton(id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON2,
              label=_('Selection Convergence'), name='radioButton2', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON2)
        self.radioButton2.SetValue(False)

        self.radioButton3 = wx.RadioButton(id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON3,
              label=_('Simultaneous Divergence'), name='radioButton3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON3)
        self.radioButton3.SetValue(False)

        self.radioButton4 = wx.RadioButton(id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON4,
              label=_('Simultaneous Convergence'), name='radioButton4', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_SFCDIVERGENCEDIALOGRADIOBUTTON4)
        self.radioButton4.SetValue(False)

        self.staticText2 = wx.StaticText(id=ID_SFCDIVERGENCEDIALOGSTATICTEXT2,
              label=_('Number of sequences:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.Sequences = wx.SpinCtrl(id=ID_SFCDIVERGENCEDIALOGSEQUENCES,
              name='Sequences', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=0, min=2, max=20)
        self.Bind(wx.EVT_SPINCTRL, self.OnSequencesChanged, id=ID_SFCDIVERGENCEDIALOGSEQUENCES)

        self.staticText3 = wx.StaticText(id=ID_SFCDIVERGENCEDIALOGSTATICTEXT3,
              label=_('Preview:'), name='staticText3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.Preview = wx.Panel(id=ID_SFCDIVERGENCEDIALOGPREVIEW,
              name='Preview', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL|wx.SIMPLE_BORDER)
        self.Preview.SetBackgroundColour(wx.Colour(255,255,255))
        setattr(self.Preview, "GetDrawingMode", lambda:FREEDRAWING_MODE)
        setattr(self.Preview, "IsOfType", ctrler.IsOfType)

        self.Spacer = wx.Panel(id=ID_SFCDIVERGENCEDIALOGSPACER,
              name='Spacer', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        
        if wx.VERSION >= (2, 5, 0):
            self.Preview.Bind(wx.EVT_PAINT, self.OnPaint)
        else:
            wx.EVT_PAINT(self.Preview, self.OnPaint)
        
        self._init_sizers()

    def __init__(self, parent, controler):
        self._init_ctrls(parent, controler)
        
        self.Divergence = None
        self.MinSize = (0, 0)
        
        self.radioButton1.SetFocus()
    
    def SetPreviewFont(self, font):
        self.Preview.SetFont(font)
    
    def GetValues(self):
        values = {}
        if self.radioButton1.GetValue():
            values["type"] = SELECTION_DIVERGENCE
        elif self.radioButton2.GetValue():
            values["type"] = SELECTION_CONVERGENCE
        elif self.radioButton3.GetValue():
            values["type"] = SIMULTANEOUS_DIVERGENCE
        else:
            values["type"] = SIMULTANEOUS_CONVERGENCE
        values["number"] = self.Sequences.GetValue()
        return values

    def SetMinSize(self, size):
        self.MinSize = size

    def OnTypeChanged(self, event):
        self.RefreshPreview()
        event.Skip()

    def OnSequencesChanged(self, event):
        self.RefreshPreview()
        event.Skip()
        
    def RefreshPreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.SetFont(self.Preview.GetFont())
        dc.Clear()
        if self.radioButton1.GetValue():
            self.Divergence = SFC_Divergence(self.Preview, SELECTION_DIVERGENCE, self.Sequences.GetValue())
        elif self.radioButton2.GetValue():
            self.Divergence = SFC_Divergence(self.Preview, SELECTION_CONVERGENCE, self.Sequences.GetValue())
        elif self.radioButton3.GetValue():
            self.Divergence = SFC_Divergence(self.Preview, SIMULTANEOUS_DIVERGENCE, self.Sequences.GetValue())
        else:
            self.Divergence = SFC_Divergence(self.Preview, SIMULTANEOUS_CONVERGENCE, self.Sequences.GetValue())
        width, height = self.Divergence.GetSize()
        min_width, min_height = max(width, self.MinSize[0]), max(height, self.MinSize[1])
        self.Divergence.SetSize(min_width, min_height)
        clientsize = self.Preview.GetClientSize()
        x = (clientsize.width - min_width) / 2
        y = (clientsize.height - min_height) / 2
        self.Divergence.SetPosition(x, y)
        self.Divergence.Draw(dc)

    def OnPaint(self, event):
        self.RefreshPreview()
        event.Skip()
