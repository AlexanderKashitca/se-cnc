# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import re
from types import TupleType

import wx

from controls import CustomEditableListBox

DIMENSION_MODEL = re.compile("([0-9]+)\.\.([0-9]+)$")

[ID_ARRAYTYPEDIALOG, ID_ARRAYTYPEDIALOGBASETYPE, 
 ID_ARRAYTYPEDIALOGDIMENSIONS, ID_ARRAYTYPEDIALOGDIALOGSTATICTEXT1, 
] = [wx.NewId() for _init_ctrls in range(4)]

class ArrayTypeDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.TopSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddWindow(self.Dimensions, 0, border=20, flag=wx.GROW|wx.ALIGN_RIGHT|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)
        
    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)
        
    def _init_coll_TopSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 1, border=0, flag=wx.GROW)
        parent.AddWindow(self.BaseType, 1, border=0, flag=wx.GROW)
    
    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=3, vgap=10)
        self.TopSizer = wx.BoxSizer(wx.HORIZONTAL)
        
        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_TopSizer_Items(self.TopSizer)
        
        self.SetSizer(self.flexGridSizer1)
    
    def _init_ctrls(self, prnt):
        wx.Dialog.__init__(self, id=ID_ARRAYTYPEDIALOG,
              name='ArrayTypeDialog', parent=prnt,
              size=wx.Size(500, 300), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER,
              title=_('Edit array type properties'))
        self.SetClientSize(wx.Size(500, 300))
        
        self.staticText1 = wx.StaticText(id=ID_ARRAYTYPEDIALOGDIALOGSTATICTEXT1,
              label=_('Base Type:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.BaseType = wx.ComboBox(id=ID_ARRAYTYPEDIALOGBASETYPE, 
              name='BaseType', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        
        self.Dimensions = CustomEditableListBox(id=ID_ARRAYTYPEDIALOGDIMENSIONS, 
              name='ArrayDimensions', parent=self, label=_("Dimensions:"), pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.gizmos.EL_ALLOW_NEW | wx.gizmos.EL_ALLOW_EDIT | wx.gizmos.EL_ALLOW_DELETE)
        for func in ["_OnLabelEndEdit", "_OnAddButton", "_OnDelButton", "_OnUpButton", "_OnDownButton"]:
            setattr(self.Dimensions, func, self.OnDimensionsChanged)
        
        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetAffirmativeButton().GetId())
        else:
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow().GetId())
        
        self._init_sizers()

    def __init__(self, parent, datatypes, infos):
        self._init_ctrls(parent)
        
        for datatype in datatypes:
            self.BaseType.Append(datatype)
        
        if isinstance(infos, TupleType) and infos[0] == "array":
            self.BaseType.SetStringSelection(infos[1])
            self.Dimensions.SetStrings(map(lambda x : "..".join(x), infos[2]))
        elif infos in datatypes:
            self.BaseType.SetStringSelection(infos)
        
        self.BaseType.SetFocus()
        
    def GetDimensions(self):
        dimensions_list = []
        for dimensions in self.Dimensions.GetStrings():
            result = DIMENSION_MODEL.match(dimensions)
            if result is None:
                message = wx.MessageDialog(self, _("\"%s\" value isn't a valid array dimension!")%dimensions, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
                return None
            bounds = result.groups()
            if int(bounds[0]) >= int(bounds[1]):
                message = wx.MessageDialog(self, _("\"%s\" value isn't a valid array dimension!\nRight value must be greater than left value.")%dimensions, _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
                return None
            dimensions_list.append(bounds)
        return dimensions_list
    
    def OnDimensionsChanged(self, event):
        wx.CallAfter(self.GetDimensions)
        event.Skip()
    
    def OnOK(self, event):
        if self.GetDimensions() is not None:
            self.EndModal(wx.ID_OK)
            
    def GetValue(self):
        return "array", self.BaseType.GetStringSelection(), self.GetDimensions()
