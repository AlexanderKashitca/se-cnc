#!/usr/bin/env python
# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx

from graphics import *

#-------------------------------------------------------------------------------
#                        Edit Ladder Element Properties Dialog
#-------------------------------------------------------------------------------


[ID_LDELEMENTDIALOG, ID_LDELEMENTDIALOGSPACER, 
 ID_LDELEMENTDIALOGNAME, ID_LDELEMENTDIALOGRADIOBUTTON1, 
 ID_LDELEMENTDIALOGRADIOBUTTON2, ID_LDELEMENTDIALOGRADIOBUTTON3,
 ID_LDELEMENTDIALOGRADIOBUTTON4, ID_LDELEMENTDIALOGRADIOBUTTON5,
 ID_LDELEMENTDIALOGRADIOBUTTON6, ID_LDELEMENTDIALOGPREVIEW,
 ID_LDELEMENTDIALOGSTATICTEXT1, ID_LDELEMENTDIALOGSTATICTEXT2, 
 ID_LDELEMENTDIALOGSTATICTEXT3, 
] = [wx.NewId() for _init_ctrls in range(13)]

class LDElementDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.MainSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)
        
    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.LeftGridSizer, 1, border=5, flag=wx.GROW|wx.RIGHT)
        parent.AddSizer(self.RightGridSizer, 1, border=5, flag=wx.GROW|wx.LEFT)
    
    def _init_coll_LeftGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=0, flag=wx.GROW)
        parent.AddSizer(self.RadioButtonSizer, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.ElementName, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Spacer, 0, border=0, flag=wx.GROW)
        
    def _init_coll_LeftGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(7)
    
    def _init_coll_RadioButtonSizer_Items(self, parent):
        parent.AddWindow(self.radioButton1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton4, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton5, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton6, 0, border=0, flag=wx.GROW)
        
    def _init_coll_RightGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Preview, 0, border=0, flag=wx.GROW)
        
    def _init_coll_RightGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)

    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.MainSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.LeftGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=5, vgap=5)
        self.RadioButtonSizer = wx.BoxSizer(wx.VERTICAL)
        self.RightGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=5)

        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_LeftGridSizer_Items(self.LeftGridSizer)
        self._init_coll_LeftGridSizer_Growables(self.LeftGridSizer)
        self._init_coll_RadioButtonSizer_Items(self.RadioButtonSizer)
        self._init_coll_RightGridSizer_Items(self.RightGridSizer)
        self._init_coll_RightGridSizer_Growables(self.RightGridSizer)

        self.SetSizer(self.flexGridSizer1)

    def _init_ctrls(self, prnt, ctrler, title, extra_size = 0):
        wx.Dialog.__init__(self, id=ID_LDELEMENTDIALOG,
              name='LDElementDialog', parent=prnt,
              size=wx.Size(350, 260 + extra_size), style=wx.DEFAULT_DIALOG_STYLE,
              title=title)
        self.SetClientSize(wx.Size(350, 260 + extra_size))

        self.staticText1 = wx.StaticText(id=ID_LDELEMENTDIALOGSTATICTEXT1,
              label=_('Modifier:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText2 = wx.StaticText(id=ID_LDELEMENTDIALOGSTATICTEXT2,
              label=_('Name:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText3 = wx.StaticText(id=ID_LDELEMENTDIALOGSTATICTEXT3,
              label=_('Preview:'), name='staticText3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.radioButton1 = wx.RadioButton(id=ID_LDELEMENTDIALOGRADIOBUTTON1,
              label=_("Normal"), name='radioButton1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=wx.RB_GROUP)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDELEMENTDIALOGRADIOBUTTON1)
        self.radioButton1.SetValue(True)

        self.radioButton2 = wx.RadioButton(id=ID_LDELEMENTDIALOGRADIOBUTTON2,
              label=_("Negated"), name='radioButton2', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDELEMENTDIALOGRADIOBUTTON2)

        self.radioButton3 = wx.RadioButton(id=ID_LDELEMENTDIALOGRADIOBUTTON3,
              label=_("Set"), name='radioButton3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDELEMENTDIALOGRADIOBUTTON3)

        self.radioButton4 = wx.RadioButton(id=ID_LDELEMENTDIALOGRADIOBUTTON4,
              label=_("Reset"), name='radioButton4', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDELEMENTDIALOGRADIOBUTTON4)

        self.radioButton5 = wx.RadioButton(id=ID_LDELEMENTDIALOGRADIOBUTTON5,
              label=_("Rising Edge"), name='radioButton5', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDELEMENTDIALOGRADIOBUTTON5)

        self.radioButton6 = wx.RadioButton(id=ID_LDELEMENTDIALOGRADIOBUTTON6,
              label=_("Falling Edge"), name='radioButton6', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDELEMENTDIALOGRADIOBUTTON6)

        self.ElementName = wx.ComboBox(id=ID_LDELEMENTDIALOGNAME,
              name='Name', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 28), style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnNameChanged, id=ID_LDELEMENTDIALOGNAME)

        self.Preview = wx.Panel(id=ID_LDELEMENTDIALOGPREVIEW,
              name='Preview', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL|wx.SIMPLE_BORDER)
        self.Preview.SetBackgroundColour(wx.Colour(255,255,255))
        setattr(self.Preview, "GetDrawingMode", lambda:FREEDRAWING_MODE)
        setattr(self.Preview, "GetScaling", lambda:None)
        setattr(self.Preview, "IsOfType", ctrler.IsOfType)

        self.Spacer = wx.Panel(id=ID_LDELEMENTDIALOGSPACER,
              name='Spacer', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        
        if wx.VERSION >= (2, 5, 0):
            self.Preview.Bind(wx.EVT_PAINT, self.OnPaint)
        else:
            wx.EVT_PAINT(self.Preview, self.OnPaint)
        
        self._init_sizers()

    def __init__(self, parent, controler, type):
        self.Type = type
        if type == "contact":
            self._init_ctrls(parent, controler, _("Edit Contact Values"))
            self.Element = LD_Contact(self.Preview, CONTACT_NORMAL, "")
            self.radioButton3.Hide()
            self.radioButton4.Hide()
        elif type == "coil":
            self._init_ctrls(parent, controler, _("Edit Coil Values"), 50)
            self.Element = LD_Coil(self.Preview, COIL_NORMAL, "")
        
        self.radioButton1.SetFocus()
    
    def SetPreviewFont(self, font):
        self.Preview.SetFont(font)
    
    def SetElementSize(self, size):
        min_width, min_height = self.Element.GetMinSize()
        width, height = max(min_width, size[0]), max(min_height, size[1])
        self.Element.SetSize(width, height)
        
    def SetVariables(self, vars):
        self.ElementName.Clear()
        for name in vars:
            self.ElementName.Append(name)
        self.ElementName.Enable(self.ElementName.GetCount() > 0)

    def SetValues(self, values):
        for name, value in values.items():
            if name == "name":
                self.Element.SetName(value)
                self.ElementName.SetStringSelection(value)
            elif name == "type":
                self.Element.SetType(value)
                if self.Type == "contact":
                    if value == CONTACT_NORMAL:
                        self.radioButton1.SetValue(True)
                    elif value == CONTACT_REVERSE:
                        self.radioButton2.SetValue(True)
                    elif value == CONTACT_RISING:
                        self.radioButton5.SetValue(True)
                    elif value == CONTACT_FALLING:
                        self.radioButton6.SetValue(True)
                elif self.Type == "coil":
                    if value == COIL_NORMAL:
                        self.radioButton1.SetValue(True)
                    elif value == COIL_REVERSE:
                        self.radioButton2.SetValue(True)
                    elif value == COIL_SET:
                        self.radioButton3.SetValue(True)
                    elif value == COIL_RESET:
                        self.radioButton4.SetValue(True)
                    elif value == COIL_RISING:
                        self.radioButton5.SetValue(True)
                    elif value == COIL_FALLING:
                        self.radioButton6.SetValue(True)

    def GetValues(self):
        values = {}
        values["name"] = self.Element.GetName()
        values["type"] = self.Element.GetType()
        values["width"], values["height"] = self.Element.GetSize()
        return values

    def OnTypeChanged(self, event):
        if self.Type == "contact":
            if self.radioButton1.GetValue():
                self.Element.SetType(CONTACT_NORMAL)
            elif self.radioButton2.GetValue():
                self.Element.SetType(CONTACT_REVERSE)
            elif self.radioButton5.GetValue():
                self.Element.SetType(CONTACT_RISING)
            elif self.radioButton6.GetValue():
                self.Element.SetType(CONTACT_FALLING)
        elif self.Type == "coil":
            if self.radioButton1.GetValue():
                self.Element.SetType(COIL_NORMAL)
            elif self.radioButton2.GetValue():
                self.Element.SetType(COIL_REVERSE)
            elif self.radioButton3.GetValue():
                self.Element.SetType(COIL_SET)
            elif self.radioButton4.GetValue():
                self.Element.SetType(COIL_RESET)
            elif self.radioButton5.GetValue():
                self.Element.SetType(COIL_RISING)
            elif self.radioButton6.GetValue():
                self.Element.SetType(COIL_FALLING)
        self.RefreshPreview()
        event.Skip()

    def OnNameChanged(self, event):
        self.Element.SetName(self.ElementName.GetStringSelection())
        self.RefreshPreview()
        event.Skip()

    def RefreshPreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.SetFont(self.Preview.GetFont())
        dc.Clear()
        clientsize = self.Preview.GetClientSize()
        width, height = self.Element.GetSize()
        self.Element.SetPosition((clientsize.width - width) / 2, (clientsize.height - height) / 2)
        self.Element.Draw(dc)

    def OnPaint(self, event):
        self.RefreshPreview()
        event.Skip()
