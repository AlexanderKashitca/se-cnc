#!/usr/bin/env python
# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx

from graphics import *

#-------------------------------------------------------------------------------
#                          Create New Block Dialog
#-------------------------------------------------------------------------------

[ID_FBDBLOCKDIALOG, ID_FBDBLOCKDIALOGNAME, 
 ID_FBDBLOCKDIALOGTYPETREE, ID_FBDBLOCKDIALOGTYPEDESC, 
 ID_FBDBLOCKDIALOGINPUTS, ID_FBDBLOCKDIALOGPREVIEW, 
 ID_FBDBLOCKDIALOGEXECUTIONORDER, ID_FBDBLOCKDIALOGEXECUTIONCONTROL, 
 ID_FBDBLOCKDIALOGSTATICTEXT1, ID_FBDBLOCKDIALOGSTATICTEXT2, 
 ID_FBDBLOCKDIALOGSTATICTEXT3, ID_FBDBLOCKDIALOGSTATICTEXT4, 
 ID_FBDBLOCKDIALOGSTATICTEXT5, ID_FBDBLOCKDIALOGSTATICTEXT6, 
] = [wx.NewId() for _init_ctrls in range(14)]

[CATEGORY, BLOCK] = range(2)

class FBDBlockDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.MainSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)

    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)

    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.LeftBoxSizer, 1, border=5, flag=wx.GROW|wx.RIGHT)
        parent.AddSizer(self.RightGridSizer, 1, border=5, flag=wx.GROW|wx.LEFT)

    def _init_coll_LeftBoxSizer_Items(self, parent):
        parent.AddWindow(self.TypeTree, 3, border=5, flag=wx.GROW|wx.BOTTOM)
        parent.AddWindow(self.TypeDesc, 1, border=0, flag=wx.GROW)

    def _init_coll_RightGridSizer_Items(self, parent):
        parent.AddSizer(self.RightUpGridSizer, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText6, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Preview, 0, border=0, flag=wx.GROW)

    def _init_coll_RightGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(2)

    def _init_coll_RightUpGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText2, 0, border=4, flag=wx.ALIGN_CENTER_VERTICAL|wx.TOP)
        parent.AddWindow(self.BlockName, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText3, 0, border=4, flag=wx.ALIGN_CENTER_VERTICAL|wx.TOP)
        parent.AddWindow(self.Inputs, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText4, 0, border=4, flag=wx.ALIGN_CENTER_VERTICAL|wx.TOP)
        parent.AddWindow(self.ExecutionOrder, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText5, 0, border=4, flag=wx.ALIGN_CENTER_VERTICAL|wx.TOP)
        parent.AddWindow(self.ExecutionControl, 0, border=0, flag=wx.GROW)
    
    def _init_coll_RightUpGridSizer_Growables(self, parent):
        parent.AddGrowableCol(1)
    
    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.MainSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.LeftBoxSizer = wx.StaticBoxSizer(self.staticbox1, wx.VERTICAL)
        self.RightGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=3, vgap=5)
        self.RightUpGridSizer = wx.FlexGridSizer(cols=2, hgap=5, rows=4, vgap=5)
        
        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_LeftBoxSizer_Items(self.LeftBoxSizer)
        self._init_coll_RightGridSizer_Items(self.RightGridSizer)
        self._init_coll_RightGridSizer_Growables(self.RightGridSizer)
        self._init_coll_RightUpGridSizer_Items(self.RightUpGridSizer)
        self._init_coll_RightUpGridSizer_Growables(self.RightUpGridSizer)
        
        self.SetSizer(self.flexGridSizer1)

    def _init_ctrls(self, prnt):
        wx.Dialog.__init__(self, id=ID_FBDBLOCKDIALOG,
              name='FBDBlockDialog', parent=prnt,
              size=wx.Size(600, 400), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER,
              title=_('Block Properties'))
        self.SetClientSize(wx.Size(600, 400))

        self.staticbox1 = wx.StaticBox(id=ID_FBDBLOCKDIALOGSTATICTEXT1,
              label=_('Type:'), name='staticBox1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 0), style=0)

        self.staticText2 = wx.StaticText(id=ID_FBDBLOCKDIALOGSTATICTEXT2,
              label=_('Name:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.staticText3 = wx.StaticText(id=ID_FBDBLOCKDIALOGSTATICTEXT2,
              label=_('Inputs:'), name='staticText4', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.staticText4 = wx.StaticText(id=ID_FBDBLOCKDIALOGSTATICTEXT4,
              label=_('Execution Order:'), name='staticText4', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.staticText5 = wx.StaticText(id=ID_FBDBLOCKDIALOGSTATICTEXT5,
              label=_('Execution Control:'), name='staticText5', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.staticText6 = wx.StaticText(id=ID_FBDBLOCKDIALOGSTATICTEXT6,
              label=_('Preview:'), name='staticText6', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)

        self.TypeTree = wx.TreeCtrl(id=ID_FBDBLOCKDIALOGTYPETREE,
              name='TypeTree', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TR_HAS_BUTTONS|wx.TR_SINGLE|wx.SUNKEN_BORDER|wx.TR_HIDE_ROOT|wx.TR_LINES_AT_ROOT)
        self.Bind(wx.EVT_TREE_SEL_CHANGED, self.OnTypeTreeItemSelected,
              id=ID_FBDBLOCKDIALOGTYPETREE)

        self.TypeDesc = wx.TextCtrl(id=ID_FBDBLOCKDIALOGTYPEDESC,
              name='TypeDesc', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TE_READONLY|wx.TE_MULTILINE)

        self.BlockName = wx.TextCtrl(id=ID_FBDBLOCKDIALOGNAME, value='',
              name='BlockName', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_TEXT, self.OnNameChanged, id=ID_FBDBLOCKDIALOGNAME)

        self.Inputs = wx.SpinCtrl(id=ID_FBDBLOCKDIALOGINPUTS,
              name='Inputs', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.SP_ARROW_KEYS, min=2, max=20)
        self.Bind(wx.EVT_SPINCTRL, self.OnInputsChanged, id=ID_FBDBLOCKDIALOGINPUTS)

        self.ExecutionOrder = wx.SpinCtrl(id=ID_FBDBLOCKDIALOGEXECUTIONORDER,
              name='ExecutionOrder', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.SP_ARROW_KEYS, min=0)
        self.Bind(wx.EVT_SPINCTRL, self.OnExecutionOrderChanged, id=ID_FBDBLOCKDIALOGEXECUTIONORDER)

        self.ExecutionControl = wx.CheckBox(id=ID_FBDBLOCKDIALOGEXECUTIONCONTROL,
              name='ExecutionControl', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_CHECKBOX, self.OnExecutionOrderChanged, id=ID_FBDBLOCKDIALOGEXECUTIONCONTROL)

        self.Preview = wx.Panel(id=ID_FBDBLOCKDIALOGPREVIEW,
              name='Preview', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL|wx.SIMPLE_BORDER)
        self.Preview.SetBackgroundColour(wx.Colour(255,255,255))
        setattr(self.Preview, "GetDrawingMode", lambda:FREEDRAWING_MODE)
        setattr(self.Preview, "GetScaling", lambda:None)
        setattr(self.Preview, "GetBlockType", self.Controler.GetBlockType)
        setattr(self.Preview, "IsOfType", self.Controler.IsOfType)

        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetAffirmativeButton().GetId())
            self.Preview.Bind(wx.EVT_PAINT, self.OnPaint)
        else:
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow().GetId())
            wx.EVT_PAINT(self.Preview, self.OnPaint)
        
        self._init_sizers()

    def __init__(self, parent, controler):
        self.Controler = controler
        self._init_ctrls(parent)
        self.BlockName.SetValue("")
        self.BlockName.Enable(False)
        self.Inputs.Enable(False)
        self.Block = None
        self.MinBlockSize = None
        self.First = True
        
        self.PouNames = []
        self.PouElementNames = []
    
        self.TypeTree.SetFocus()
    
    def SetPreviewFont(self, font):
        self.Preview.SetFont(font)
    
    def FindTreeItem(self, root, name, inputs = None):
        if root.IsOk():
            pydata = self.TypeTree.GetPyData(root)
            if pydata is not None:
                type_inputs = pydata.get("inputs", None)
                type_extension = pydata.get("extension", None)
                if inputs is not None and type_inputs is not None:
                    if type_extension is not None:
                        same_inputs = type_inputs == inputs[:type_extension]
                    else:
                        same_inputs = type_inputs == inputs
                else:
                    same_inputs = True
            if pydata is not None and self.TypeTree.GetItemText(root) == name and same_inputs:
                return root
            else:
                if wx.VERSION < (2, 6, 0):
                    item, root_cookie = self.TypeTree.GetFirstChild(root, 0)
                else:
                    item, root_cookie = self.TypeTree.GetFirstChild(root)
                while item.IsOk():
                    result = self.FindTreeItem(item, name, inputs)
                    if result:
                        return result
                    item, root_cookie = self.TypeTree.GetNextChild(root, root_cookie)
        return None
    
    def OnOK(self, event):
        selected = self.TypeTree.GetSelection()
        block_name = self.BlockName.GetValue()
        name_enabled = self.BlockName.IsEnabled()
        if not selected.IsOk() or self.TypeTree.GetItemParent(selected) == self.TypeTree.GetRootItem() or selected == self.TypeTree.GetRootItem():
            message = wx.MessageDialog(self, _("Form isn't complete. Valid block type must be selected!"), _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif name_enabled and block_name == "":
            message = wx.MessageDialog(self, _("Form isn't complete. Name must be filled!"), _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif name_enabled and not TestIdentifier(block_name):
            message = wx.MessageDialog(self, _("\"%s\" is not a valid identifier!")%block_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif name_enabled and block_name.upper() in IEC_KEYWORDS:
            message = wx.MessageDialog(self, _("\"%s\" is a keyword. It can't be used!")%block_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif name_enabled and block_name.upper() in self.PouNames:
            message = wx.MessageDialog(self, _("\"%s\" pou already exists!")%block_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        elif name_enabled and block_name.upper() in self.PouElementNames:
            message = wx.MessageDialog(self, _("\"%s\" element for this pou already exists!")%block_name, _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        else:
            self.EndModal(wx.ID_OK)

    def SetBlockList(self, blocktypes):
        root = self.TypeTree.AddRoot("")
        for category in blocktypes:
            category_name = category["name"]
            category_item = self.TypeTree.AppendItem(root, _(category_name))
            self.TypeTree.SetPyData(category_item, {"type" : CATEGORY})
            for blocktype in category["list"]:
                blocktype_item = self.TypeTree.AppendItem(category_item, blocktype["name"])
                block_data = {"type" : BLOCK, 
                              "inputs" : tuple([type for name, type, modifier in blocktype["inputs"]]),
                              "extension" : None}
                if blocktype["extensible"]:
                    block_data["extension"] = len(blocktype["inputs"])
                self.TypeTree.SetPyData(blocktype_item, block_data)
        
    def SetMinBlockSize(self, size):
        self.MinBlockSize = size

    def SetPouNames(self, pou_names):
        self.PouNames = [pou_name.upper() for pou_name in pou_names]
        
    def SetPouElementNames(self, element_names):
        self.PouElementNames = [element_name.upper() for element_name in element_names]
        
    def SetValues(self, values):
        blocktype = values.get("type", None)
        if blocktype is not None:
            inputs = values.get("inputs", None)
            item = self.FindTreeItem(self.TypeTree.GetRootItem(), blocktype, inputs)
            if item:
                self.TypeTree.SelectItem(item)
                self.TypeTree.EnsureVisible(item)
        for name, value in values.items():
            if name == "name":
                self.BlockName.SetValue(value)
            elif name == "extension":
                self.Inputs.SetValue(value)
            elif name == "executionOrder":
                self.ExecutionOrder.SetValue(value)
            elif name == "executionControl":
                   self.ExecutionControl.SetValue(value)
        self.RefreshPreview()

    def GetValues(self):
        values = {}
        item = self.TypeTree.GetSelection()
        values["type"] = self.TypeTree.GetItemText(item)
        values["inputs"] = self.TypeTree.GetPyData(item)["inputs"]
        if self.BlockName.GetValue() != "":
            values["name"] = self.BlockName.GetValue()
        values["width"], values["height"] = self.Block.GetSize()
        values["extension"] = self.Inputs.GetValue()
        values["executionOrder"] = self.ExecutionOrder.GetValue()
        values["executionControl"] = self.ExecutionControl.GetValue()
        return values

    def OnTypeTreeItemSelected(self, event):
        selected = event.GetItem()
        pydata = self.TypeTree.GetPyData(selected)
        if pydata["type"] != CATEGORY:
            blocktype = self.Controler.GetBlockType(self.TypeTree.GetItemText(selected), pydata["inputs"])
            if blocktype:
                self.Inputs.SetValue(len(blocktype["inputs"]))
                self.Inputs.Enable(blocktype["extensible"])
                self.BlockName.Enable(blocktype["type"] != "function")
                comment = blocktype["comment"]
                self.TypeDesc.SetValue(_(comment) + blocktype.get("usage", ""))
                wx.CallAfter(self.RefreshPreview)
            else:
                self.BlockName.Enable(False)
                self.Inputs.Enable(False)
                self.Inputs.SetValue(2)
                self.TypeDesc.SetValue("")
                wx.CallAfter(self.ErasePreview)
        else:
            self.BlockName.Enable(False)
            self.Inputs.Enable(False)
            self.Inputs.SetValue(2)
            self.TypeDesc.SetValue("")
            wx.CallAfter(self.ErasePreview)
        event.Skip()

    def OnNameChanged(self, event):
        if self.BlockName.IsEnabled():
            self.RefreshPreview()
        event.Skip()
    
    def OnInputsChanged(self, event):
        if self.Inputs.IsEnabled():
            self.RefreshPreview()
        event.Skip()
    
    def OnExecutionOrderChanged(self, event):
        self.RefreshPreview()
        event.Skip()
    
    def OnExecutionControlChanged(self, event):
        self.RefreshPreview()
        event.Skip()
    
    def ErasePreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.Clear()
        self.Block = None
        
    def RefreshPreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.SetFont(self.Preview.GetFont())
        dc.Clear()
        item = self.TypeTree.GetSelection()
        if item.IsOk():
            pydata = self.TypeTree.GetPyData(item)
            if pydata["type"] == CATEGORY:
                self.Block = None
            else:
                blocktype = self.TypeTree.GetItemText(item)
                if blocktype:
                    self.Block = FBD_Block(self.Preview, blocktype, 
                            self.BlockName.GetValue(), 
                            extension = self.Inputs.GetValue(), 
                            inputs = pydata["inputs"], 
                            executionControl = self.ExecutionControl.GetValue(), 
                            executionOrder = self.ExecutionOrder.GetValue())
                    width, height = self.MinBlockSize
                    min_width, min_height = self.Block.GetMinSize()
                    width, height = max(min_width, width), max(min_height, height)
                    self.Block.SetSize(width, height)
                    clientsize = self.Preview.GetClientSize()
                    x = (clientsize.width - width) / 2
                    y = (clientsize.height - height) / 2
                    self.Block.SetPosition(x, y)
                    self.Block.Draw(dc)
                else:
                    self.Block = None

    def OnPaint(self, event):
        if self.Block is not None:
            self.RefreshPreview()
        event.Skip()
