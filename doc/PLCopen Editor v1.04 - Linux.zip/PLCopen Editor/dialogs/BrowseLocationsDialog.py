#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import os

import wx

from plcopen.structures import LOCATIONDATATYPES
from PLCControler import LOCATION_PLUGIN, LOCATION_MODULE, LOCATION_GROUP, LOCATION_VAR_INPUT, LOCATION_VAR_OUTPUT, LOCATION_VAR_MEMORY

CWD = os.path.split(os.path.split(os.path.realpath(__file__))[0])[0]

def GetDirChoiceOptions():
    _ = lambda x : x
    return [(_("All"), [LOCATION_VAR_INPUT, LOCATION_VAR_OUTPUT, LOCATION_VAR_MEMORY]), 
            (_("Input"), [LOCATION_VAR_INPUT]), 
            (_("Output"), [LOCATION_VAR_OUTPUT]), 
            (_("Memory"), [LOCATION_VAR_MEMORY])]
DIRCHOICE_OPTIONS_FILTER = dict([(_(option), filter) for option, filter in GetDirChoiceOptions()])

# turn LOCATIONDATATYPES inside-out
LOCATION_SIZES = {}
for size, types in LOCATIONDATATYPES.iteritems():
    for type in types:
        LOCATION_SIZES[type] = size

[ID_BROWSELOCATIONSDIALOG, ID_BROWSELOCATIONSDIALOGLOCATIONSTREE, 
 ID_BROWSELOCATIONSDIALOGDIRCHOICE, ID_BROWSELOCATIONSDIALOGSTATICTEXT1, 
 ID_BROWSELOCATIONSDIALOGSTATICTEXT2, 
] = [wx.NewId() for _init_ctrls in range(5)]

class BrowseLocationsDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=20, flag=wx.TOP|wx.LEFT|wx.RIGHT|wx.GROW)
        parent.AddWindow(self.LocationsTree, 0, border=20, flag=wx.LEFT|wx.RIGHT|wx.GROW)
        parent.AddSizer(self.ButtonGridSizer, 0, border=20, flag=wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.GROW)
        
    def _init_coll_MainSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)
    
    def _init_coll_ButtonGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText2, 0, border=0, flag=wx.ALIGN_CENTER_VERTICAL)
        parent.AddWindow(self.DirChoice, 0, border=0, flag=wx.ALIGN_CENTER_VERTICAL)
        parent.AddSizer(self.ButtonSizer, 0, border=0, flag=wx.ALIGN_RIGHT)
        
    def _init_coll_ButtonGridSizer_Growables(self, parent):
        parent.AddGrowableCol(2)
        parent.AddGrowableRow(0)
    
    def _init_sizers(self):
        self.MainSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=3, vgap=10)
        self.ButtonGridSizer = wx.FlexGridSizer(cols=3, hgap=5, rows=1, vgap=0)
        
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_MainSizer_Growables(self.MainSizer)
        self._init_coll_ButtonGridSizer_Items(self.ButtonGridSizer)
        self._init_coll_ButtonGridSizer_Growables(self.ButtonGridSizer)
        
        self.SetSizer(self.MainSizer)
    
    def _init_ctrls(self, prnt):
        wx.Dialog.__init__(self, id=ID_BROWSELOCATIONSDIALOG, 
              name='BrowseLocationsDialog', parent=prnt,  
              size=wx.Size(600, 400), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER,
              title=_('Browse Locations'))
    
        self.staticText1 = wx.StaticText(id=ID_BROWSELOCATIONSDIALOGSTATICTEXT1,
              label=_('Locations available:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)
        
        if wx.Platform == '__WXMSW__':
            treestyle = wx.TR_HAS_BUTTONS|wx.TR_SINGLE|wx.SUNKEN_BORDER
        else:
            treestyle = wx.TR_HAS_BUTTONS|wx.TR_HIDE_ROOT|wx.TR_SINGLE|wx.SUNKEN_BORDER
        self.LocationsTree = wx.TreeCtrl(id=ID_BROWSELOCATIONSDIALOGLOCATIONSTREE,
              name='LocationsTree', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=treestyle)
        self.Bind(wx.EVT_TREE_ITEM_ACTIVATED, self.OnLocationsTreeItemActivated, 
                  id=ID_BROWSELOCATIONSDIALOGLOCATIONSTREE)
        
        self.staticText2 = wx.StaticText(id=ID_BROWSELOCATIONSDIALOGSTATICTEXT2,
              label=_('Direction:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.DefaultSize, style=0)
        
        self.DirChoice = wx.ComboBox(id=ID_BROWSELOCATIONSDIALOGDIRCHOICE,
              name='DirChoice', parent=self, pos=wx.Point(0, 0),
              size=wx.DefaultSize, style=wx.CB_READONLY)
        self.Bind(wx.EVT_COMBOBOX, self.OnDirChoice, id=ID_BROWSELOCATIONSDIALOGDIRCHOICE)
        
        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetAffirmativeButton().GetId())
        else:
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow().GetId())
        
        self._init_sizers()
    
    def __init__(self, parent, var_type, locations):
        self._init_ctrls(parent)
        self.VarType = var_type
        self.Locations = locations
        
        # Define Tree item icon list
        self.TreeImageList = wx.ImageList(16, 16)
        self.TreeImageDict = {}
        
        # Icons for items
        for imgname, itemtype in [
            ("CONFIGURATION", LOCATION_PLUGIN), 
            ("RESOURCE",      LOCATION_MODULE), 
            ("PROGRAM",       LOCATION_GROUP), 
            ("VAR_INPUT",     LOCATION_VAR_INPUT), 
            ("VAR_OUTPUT",    LOCATION_VAR_OUTPUT), 
            ("VAR_LOCAL",     LOCATION_VAR_MEMORY)]:
            self.TreeImageDict[itemtype]=self.TreeImageList.Add(wx.Bitmap(os.path.join(CWD, 'Images', '%s.png'%imgname)))
        
        # Assign icon list to TreeCtrls
        self.LocationsTree.SetImageList(self.TreeImageList)
        
        # Set a options for the choice
        for option, filter in GetDirChoiceOptions():
            self.DirChoice.Append(_(option))
        self.DirChoice.SetStringSelection(_("All"))
        self.RefreshFilter()
        
        self.RefreshLocationsTree()
    
    def RefreshFilter(self):
        self.Filter = DIRCHOICE_OPTIONS_FILTER[self.DirChoice.GetStringSelection()]
    
    def RefreshLocationsTree(self):
        root = self.LocationsTree.GetRootItem()
        if not root.IsOk():
            if wx.Platform == '__WXMSW__':
                root = self.LocationsTree.AddRoot(_('Plugins'))
            else:
                root = self.LocationsTree.AddRoot("")
        self.GenerateLocationsTreeBranch(root, self.Locations)
        self.LocationsTree.Expand(root)
    
    def GenerateLocationsTreeBranch(self, root, locations):
        to_delete = []
        if wx.VERSION >= (2, 6, 0):
            item, root_cookie = self.LocationsTree.GetFirstChild(root)
        else:
            item, root_cookie = self.LocationsTree.GetFirstChild(root, 0)
        for loc_infos in locations:
            infos = loc_infos.copy()
            if infos["type"] in [LOCATION_PLUGIN, LOCATION_MODULE, LOCATION_GROUP] or\
               infos["type"] in self.Filter and (infos["IEC_type"] == self.VarType or
               infos["IEC_type"] is None and LOCATION_SIZES[self.VarType] == infos["size"]):
                children = [child for child in infos.pop("children")]
                if not item.IsOk():
                    item = self.LocationsTree.AppendItem(root, infos["name"])
                    if wx.Platform != '__WXMSW__':
                        item, root_cookie = self.LocationsTree.GetNextChild(root, root_cookie)
                else:
                    self.LocationsTree.SetItemText(item, infos["name"])
                self.LocationsTree.SetPyData(item, infos)
                self.LocationsTree.SetItemImage(item, self.TreeImageDict[infos["type"]])
                self.GenerateLocationsTreeBranch(item, children)
                item, root_cookie = self.LocationsTree.GetNextChild(root, root_cookie)
        while item.IsOk():
            to_delete.append(item)
            item, root_cookie = self.LocationsTree.GetNextChild(root, root_cookie)
        for item in to_delete:
            self.LocationsTree.Delete(item)
    
    def OnLocationsTreeItemActivated(self, event):
        infos = self.LocationsTree.GetPyData(event.GetItem())
        if infos["type"] not in [LOCATION_PLUGIN, LOCATION_MODULE, LOCATION_GROUP]:
            wx.CallAfter(self.EndModal, wx.ID_OK)
        event.Skip()
    
    def OnDirChoice(self, event):
        self.RefreshFilter()
        self.RefreshLocationsTree()
        
    def GetValues(self):
        selected = self.LocationsTree.GetSelection()
        return self.LocationsTree.GetPyData(selected)
        
    def OnOK(self, event):
        selected = self.LocationsTree.GetSelection()
        var_infos = None
        if selected.IsOk():
            var_infos = self.LocationsTree.GetPyData(selected)
        if var_infos is None or var_infos["type"] in [LOCATION_PLUGIN, LOCATION_MODULE, LOCATION_GROUP]:
            message = wx.MessageDialog(self, _("A location must be selected!"), _("Error"), wx.OK|wx.ICON_ERROR)
            message.ShowModal()
            message.Destroy()
        else:
            self.EndModal(wx.ID_OK)
