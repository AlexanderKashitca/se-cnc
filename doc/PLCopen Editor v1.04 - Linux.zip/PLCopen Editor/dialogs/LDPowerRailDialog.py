# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import wx

from graphics import *


#-------------------------------------------------------------------------------
#                      Edit Ladder Power Rail Properties Dialog
#-------------------------------------------------------------------------------


[ID_LDPOWERRAILDIALOG, ID_LDPOWERRAILDIALOGSPACER, 
 ID_LDPOWERRAILDIALOGTYPE, ID_LDPOWERRAILDIALOGRADIOBUTTON1, 
 ID_LDPOWERRAILDIALOGRADIOBUTTON2, ID_LDPOWERRAILDIALOGPREVIEW,
 ID_LDPOWERRAILDIALOGSTATICTEXT1, ID_LDPOWERRAILDIALOGSTATICTEXT2, 
 ID_LDPOWERRAILDIALOGSTATICTEXT3, ID_LDPOWERRAILDIALOGPINNUMBER,
] = [wx.NewId() for _init_ctrls in range(10)]

class LDPowerRailDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)
    
    def _init_coll_flexGridSizer1_Items(self, parent):
        parent.AddSizer(self.MainSizer, 0, border=20, flag=wx.GROW|wx.TOP|wx.LEFT|wx.RIGHT)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.ALIGN_RIGHT|wx.BOTTOM|wx.LEFT|wx.RIGHT)
        
    def _init_coll_flexGridSizer1_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)
    
    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.LeftGridSizer, 1, border=5, flag=wx.GROW|wx.RIGHT)
        parent.AddSizer(self.RightGridSizer, 1, border=5, flag=wx.GROW|wx.LEFT)
    
    def _init_coll_LeftGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton1, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.radioButton2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.staticText2, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.PinNumber, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Spacer, 0, border=0, flag=wx.GROW)
    
    def _init_coll_LeftGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(5)
            
    def _init_coll_RightGridSizer_Items(self, parent):
        parent.AddWindow(self.staticText3, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Preview, 0, border=0, flag=wx.GROW)
        
    def _init_coll_RightGridSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(1)

    def _init_sizers(self):
        self.flexGridSizer1 = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.MainSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.LeftGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=6, vgap=5)
        self.RightGridSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=5)

        self._init_coll_flexGridSizer1_Items(self.flexGridSizer1)
        self._init_coll_flexGridSizer1_Growables(self.flexGridSizer1)
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_LeftGridSizer_Items(self.LeftGridSizer)
        self._init_coll_LeftGridSizer_Growables(self.LeftGridSizer)
        self._init_coll_RightGridSizer_Items(self.RightGridSizer)
        self._init_coll_RightGridSizer_Growables(self.RightGridSizer)

        self.SetSizer(self.flexGridSizer1)

    def _init_ctrls(self, prnt, ctrler):
        wx.Dialog.__init__(self, id=ID_LDPOWERRAILDIALOG,
              name='PowerRailDialog', parent=prnt,
              size=wx.Size(350, 260), style=wx.DEFAULT_DIALOG_STYLE,
              title=_('Power Rail Properties'))
        self.SetClientSize(wx.Size(350, 260))

        self.staticText1 = wx.StaticText(id=ID_LDPOWERRAILDIALOGSTATICTEXT1,
              label=_('Type:'), name='staticText1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText2 = wx.StaticText(id=ID_LDPOWERRAILDIALOGSTATICTEXT2,
              label=_('Pin number:'), name='staticText2', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.staticText3 = wx.StaticText(id=ID_LDPOWERRAILDIALOGSTATICTEXT3,
              label=_('Preview:'), name='staticText3', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)

        self.radioButton1 = wx.RadioButton(id=ID_LDPOWERRAILDIALOGRADIOBUTTON1,
              label=_('Left PowerRail'), name='radioButton1', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=wx.RB_GROUP)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDPOWERRAILDIALOGRADIOBUTTON1)
        self.radioButton1.SetValue(True)

        self.radioButton2 = wx.RadioButton(id=ID_LDPOWERRAILDIALOGRADIOBUTTON2,
              label=_('Right PowerRail'), name='radioButton2', parent=self, 
              pos=wx.Point(0, 0), size=wx.Size(0, 24), style=0)
        self.Bind(wx.EVT_RADIOBUTTON, self.OnTypeChanged, id=ID_LDPOWERRAILDIALOGRADIOBUTTON2)

        self.PinNumber = wx.SpinCtrl(id=ID_LDPOWERRAILDIALOGPINNUMBER,
              name='PinNumber', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.SP_ARROW_KEYS, min=1, max=50)
        self.Bind(wx.EVT_SPINCTRL, self.OnPinNumberChanged, id=ID_LDPOWERRAILDIALOGPINNUMBER)

        self.Preview = wx.Panel(id=ID_LDPOWERRAILDIALOGPREVIEW,
              name='Preview', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL|wx.SIMPLE_BORDER)
        self.Preview.SetBackgroundColour(wx.Colour(255,255,255))
        setattr(self.Preview, "GetDrawingMode", lambda:FREEDRAWING_MODE)
        setattr(self.Preview, "GetScaling", lambda:None)
        setattr(self.Preview, "IsOfType", ctrler.IsOfType)

        self.Spacer = wx.Panel(id=ID_LDPOWERRAILDIALOGSPACER,
              name='Spacer', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 0), style=wx.TAB_TRAVERSAL)

        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        
        if wx.VERSION >= (2, 5, 0):
            self.Preview.Bind(wx.EVT_PAINT, self.OnPaint)
        else:
            wx.EVT_PAINT(self.Preview, self.OnPaint)
        
        self._init_sizers()

    def __init__(self, parent, controler, type = LEFTRAIL, number = 1):
        self._init_ctrls(parent, controler)
        self.Type = type
        if type == LEFTRAIL:
            self.radioButton1.SetValue(True)
        elif type == RIGHTRAIL:
            self.radioButton2.SetValue(True)
        self.PinNumber.SetValue(number)
        
        self.PowerRailMinSize = (0, 0)
        self.PowerRail = None
        
        self.radioButton1.SetFocus()

    def SetPreviewFont(self, font):
        self.Preview.SetFont(font)

    def SetMinSize(self, size):
        self.PowerRailMinSize = size
        self.RefreshPreview()    

    def GetValues(self):
        values = {}
        values["type"] = self.Type
        values["number"] = self.PinNumber.GetValue()
        values["width"], values["height"] = self.PowerRail.GetSize()
        return values

    def OnTypeChanged(self, event):
        if self.radioButton1.GetValue():
            self.Type = LEFTRAIL
        elif self.radioButton2.GetValue():
            self.Type = RIGHTRAIL
        self.RefreshPreview()
        event.Skip()

    def OnPinNumberChanged(self, event):
        self.RefreshPreview()
        event.Skip()

    def RefreshPreview(self):
        dc = wx.ClientDC(self.Preview)
        dc.SetFont(self.Preview.GetFont())
        dc.Clear()
        self.PowerRail = LD_PowerRail(self.Preview, self.Type, connectors = self.PinNumber.GetValue())
        min_width, min_height = 2, LD_LINE_SIZE * self.PinNumber.GetValue()
        width, height = max(min_width, self.PowerRailMinSize[0]), max(min_height, self.PowerRailMinSize[1])
        self.PowerRail.SetSize(width, height)
        clientsize = self.Preview.GetClientSize()
        self.PowerRail.SetPosition((clientsize.width - width) / 2, (clientsize.height - height) / 2)
        self.PowerRail.Draw(dc)

    def OnPaint(self, event):
        self.RefreshPreview()
        event.Skip()
