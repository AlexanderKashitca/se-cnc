#!/usr/bin/env python
# -*- coding: utf-8 -*-

#This file is part of PLCOpenEditor, a library implementing an IEC 61131-3 editor
#based on the plcopen standard. 
#
#Copyright (C) 2007: Edouard TISSERANT and Laurent BESSARD
#
#See COPYING file for copyrights details.
#
#This library is free software; you can redistribute it and/or
#modify it under the terms of the GNU General Public
#License as published by the Free Software Foundation; either
#version 2.1 of the License, or (at your option) any later version.
#
#This library is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#General Public License for more details.
#
#You should have received a copy of the GNU General Public
#License along with this library; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import re

import wx

MICROSECONDS = 0.001
MILLISECONDS = 1
SECOND = 1000
MINUTE = 60 * SECOND
HOUR = 60 * MINUTE
DAY = 24 * HOUR

IEC_TIME_MODEL = re.compile("(?:(?:T|TIME)#)?(-)?(?:(%(float)s)D_?)?(?:(%(float)s)H_?)?(?:(%(float)s)M(?!S)_?)?(?:(%(float)s)S_?)?(?:(%(float)s)MS)?" % {"float": "[0-9]+(?:\.[0-9]+)?"})

#-------------------------------------------------------------------------------
#                         Edit Duration Value Dialog
#-------------------------------------------------------------------------------

[ID_DURATIONEDITORDIALOG, ID_DURATIONEDITORDIALOGDAYSLABEL,
 ID_DURATIONEDITORDIALOGDAYS, ID_DURATIONEDITORDIALOGHOURSLABEL, 
 ID_DURATIONEDITORDIALOGHOURS, ID_DURATIONEDITORDIALOGMINUTESLABEL,
 ID_DURATIONEDITORDIALOGMINUTES, ID_DURATIONEDITORDIALOGSECONDSLABEL, 
 ID_DURATIONEDITORDIALOGSECONDS, ID_DURATIONEDITORDIALOGMILLISECONDSLABEL,
 ID_DURATIONEDITORDIALOGMILLISECONDS, ID_DURATIONEDITORDIALOGMICROSECONDSLABEL,
 ID_DURATIONEDITORDIALOGMICROSECONDS, 
] = [wx.NewId() for _init_ctrls in range(13)]

class DurationEditorDialog(wx.Dialog):
    
    if wx.VERSION < (2, 6, 0):
        def Bind(self, event, function, id = None):
            if id is not None:
                event(self, id, function)
            else:
                event(self, function)

    def _init_coll_MainSizer_Items(self, parent):
        parent.AddSizer(self.ControlsSizer, 0, border=20, flag=wx.TOP|wx.LEFT|wx.RIGHT|wx.GROW)
        parent.AddSizer(self.ButtonSizer, 0, border=20, flag=wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.GROW)
        
    def _init_coll_MainSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableRow(0)
        
    def _init_coll_ControlsSizer_Items(self, parent):
        parent.AddWindow(self.DaysLabel, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.HoursLabel, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.MinutesLabel, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.SecondsLabel, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.MillisecondsLabel, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.MicrosecondsLabel, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Days, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Hours, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Minutes, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Seconds, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Milliseconds, 0, border=0, flag=wx.GROW)
        parent.AddWindow(self.Microseconds, 0, border=0, flag=wx.GROW)
        
    def _init_coll_ControlsSizer_Growables(self, parent):
        parent.AddGrowableCol(0)
        parent.AddGrowableCol(1)
        parent.AddGrowableCol(2)
        parent.AddGrowableCol(3)
        parent.AddGrowableCol(4)
        parent.AddGrowableCol(5)

    def _init_sizers(self):
        self.MainSizer = wx.FlexGridSizer(cols=1, hgap=0, rows=2, vgap=10)
        self.ControlsSizer = wx.FlexGridSizer(cols=6, hgap=10, rows=2, vgap=10)
        
        self._init_coll_MainSizer_Items(self.MainSizer)
        self._init_coll_MainSizer_Growables(self.MainSizer)
        self._init_coll_ControlsSizer_Items(self.ControlsSizer)
        self._init_coll_ControlsSizer_Growables(self.ControlsSizer)
        
        self.SetSizer(self.MainSizer)

    def _init_ctrls(self, prnt):
        wx.Dialog.__init__(self, id=ID_DURATIONEDITORDIALOG, 
              name='DurationEditorDialog', parent=prnt,  
              size=wx.Size(700, 200), style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER,
              title=_('Edit Duration'))
        
        self.DaysLabel = wx.StaticText(id=ID_DURATIONEDITORDIALOGDAYSLABEL,
              label=_('Days:'), name='DaysLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.Days = wx.TextCtrl(id=ID_DURATIONEDITORDIALOGDAYS, value='0',
              name='Days', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TE_PROCESS_ENTER)
        self.Bind(wx.EVT_TEXT_ENTER, self.GetControlValueTestFunction(self.Days), id=ID_DURATIONEDITORDIALOGDAYS)
        
        self.HoursLabel = wx.StaticText(id=ID_DURATIONEDITORDIALOGHOURSLABEL,
              label=_('Hours:'), name='HoursLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.Hours = wx.TextCtrl(id=ID_DURATIONEDITORDIALOGHOURS, value='0',
              name='Hours', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TE_PROCESS_ENTER)
        self.Bind(wx.EVT_TEXT_ENTER, self.GetControlValueTestFunction(self.Hours), id=ID_DURATIONEDITORDIALOGHOURS)
        
        self.MinutesLabel = wx.StaticText(id=ID_DURATIONEDITORDIALOGMINUTESLABEL,
              label=_('Minutes:'), name='MinutesLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.Minutes = wx.TextCtrl(id=ID_DURATIONEDITORDIALOGMINUTES, value='0',
              name='Minutes', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TE_PROCESS_ENTER)
        self.Bind(wx.EVT_TEXT_ENTER, self.GetControlValueTestFunction(self.Minutes), id=ID_DURATIONEDITORDIALOGMINUTES)
        
        self.SecondsLabel = wx.StaticText(id=ID_DURATIONEDITORDIALOGSECONDSLABEL,
              label=_('Seconds:'), name='SecondsLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.Seconds = wx.TextCtrl(id=ID_DURATIONEDITORDIALOGSECONDS, value='0',
              name='Seconds', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TE_PROCESS_ENTER)
        self.Bind(wx.EVT_TEXT_ENTER, self.GetControlValueTestFunction(self.Seconds), id=ID_DURATIONEDITORDIALOGSECONDS)
        
        self.MillisecondsLabel = wx.StaticText(id=ID_DURATIONEDITORDIALOGMILLISECONDSLABEL,
              label=_('Milliseconds:'), name='MillisecondsLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.Milliseconds = wx.TextCtrl(id=ID_DURATIONEDITORDIALOGMILLISECONDS, value='0',
              name='Milliseconds', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TE_PROCESS_ENTER)
        self.Bind(wx.EVT_TEXT_ENTER, self.GetControlValueTestFunction(self.Milliseconds), id=ID_DURATIONEDITORDIALOGMILLISECONDS)
        
        self.MicrosecondsLabel = wx.StaticText(id=ID_DURATIONEDITORDIALOGMICROSECONDSLABEL,
              label=_('Microseconds:'), name='MicrosecondsLabel', parent=self,
              pos=wx.Point(0, 0), size=wx.Size(0, 17), style=0)
        
        self.Microseconds = wx.TextCtrl(id=ID_DURATIONEDITORDIALOGMICROSECONDS, value='0',
              name='Microseconds', parent=self, pos=wx.Point(0, 0),
              size=wx.Size(0, 24), style=wx.TE_PROCESS_ENTER)
        self.Bind(wx.EVT_TEXT_ENTER, self.GetControlValueTestFunction(self.Milliseconds), id=ID_DURATIONEDITORDIALOGMICROSECONDS)
        
        self.ButtonSizer = self.CreateButtonSizer(wx.OK|wx.CANCEL|wx.CENTRE)
        if wx.VERSION >= (2, 5, 0):
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetAffirmativeButton().GetId())
        else:
            self.Bind(wx.EVT_BUTTON, self.OnOK, id=self.ButtonSizer.GetChildren()[0].GetSizer().GetChildren()[0].GetWindow().GetId())
        
        self._init_sizers()
    
    def __init__(self, parent):
        self._init_ctrls(parent)
        
        self.Days.SetFocus()
        
    def SetDuration(self, value):
        result = IEC_TIME_MODEL.match(value.upper())
        if result is not None:
            values = result.groups()
            for control, index in [(self.Days, 1), (self.Hours, 2),
                                   (self.Minutes, 3), (self.Seconds, 4)]:
                value = values[index]
                if value is not None:
                    control.SetValue(value)
                else:
                    control.SetValue("0")
            milliseconds = values[5]
            if milliseconds is not None:
                self.Milliseconds.SetValue("%d" % int(float(milliseconds)))
                self.Microseconds.SetValue("%.3f" % ((float(milliseconds) % MILLISECONDS) / MICROSECONDS))
            else:
                self.Milliseconds.SetValue("0")
                self.Microseconds.SetValue("0")
        
    def GetControlValueTestFunction(self, control):
        def OnValueChanged(event):
            try:
                value = float(control.GetValue())
            except ValueError, e:
                message = wx.MessageDialog(self, _("Invalid value!\nYou must fill a numeric value."), _("Error"), wx.OK|wx.ICON_ERROR)
                message.ShowModal()
                message.Destroy()
            event.Skip()
        return OnValueChanged

    def GetDuration(self):
        milliseconds = 0
        for control, factor in [(self.Days, DAY), (self.Hours, HOUR),
                                (self.Minutes, MINUTE), (self.Seconds, SECOND),
                                (self.Milliseconds, MILLISECONDS), (self.Microseconds, MICROSECONDS)]:
            
            milliseconds += float(control.GetValue()) * factor
        
        not_null = False
        duration = "T#"
        for value, format in [(int(milliseconds) / DAY, "%dd"),
                            ((int(milliseconds) % DAY) / HOUR, "%dh"),
                            ((int(milliseconds) % HOUR) / MINUTE, "%dm"),
                            ((int(milliseconds) % MINUTE) / SECOND, "%ds")]:
            
            if value > 0 or not_null:
                duration += format % value
                not_null = True
        
        duration += "%gms" % (milliseconds % SECOND)
        return duration
    
    def OnOK(self, event):
        errors = []
        for control, name in [(self.Days, "days"), (self.Hours, "hours"), 
                              (self.Minutes, "minutes"), (self.Seconds, "seconds"),
                              (self.Milliseconds, "milliseconds")]:
            try:
                value = float(control.GetValue())
            except ValueError, e:
                errors.append(name)
        if len(errors) > 0:
            if len(errors) == 1:
                message = _("Field %s hasn't a valid value!") % errors[0]
            else:
                message = _("Fields %s haven't a valid value!") % ",".join(errors)
            dialog = wx.MessageDialog(self, message, _("Error"), wx.OK|wx.ICON_ERROR)
            dialog.ShowModal()
            dialog.Destroy()
        else:
            self.EndModal(wx.ID_OK)
